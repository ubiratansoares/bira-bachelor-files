    var XMLHttpRequestObject2 = false;
	var img = new Image();
	img.src = "rss_include/loading.gif";
    
    if ( window.XMLHttpRequest )
        XMLHttpRequestObject2 = new XMLHttpRequest();
    else if (window.ActiveXObject)
        XMLHttpRequestObject2 = new ActiveXObject("Microsoft.XMLHTTP");

	function changeOptions()
	{
		LoadFeed();
	}
	
	function LoadFeed(value, initial)
	{
        if ( XMLHttpRequestObject2 )
        {
			if ( AjaxBusy() )
			{
				setTimeout( function(){LoadFeed(value, initial); value=null; initial=null;}, 300);
				return;
			}
			var dsource = "rss_include/ajax.php?loadfeed"; 

			if (value)
				dsource += "=" + value;
			else
			{
				var val = document.getElementById("rss_feed").value;
				if ( val == "" )
					document.getElementById("rss_feed").selectedIndex += 1;

				dsource += "=" + document.getElementById("rss_feed").value;
			}

			dsource += "&fulltext=" + document.getElementById("showtext").checked;
			dsource += "&showimages=" + document.getElementById("showimages").checked;
			
            XMLHttpRequestObject2.open("GET",dsource);
            XMLHttpRequestObject2.onreadystatechange = function()
            {
				if ( XMLHttpRequestObject2.readyState != 4 )
				{
					document.getElementById("rss_div").innerHTML = "<center><img src=\"" + img.src + "\"> <font class=\"graytext\">Loading Feed</font></center>";	
				}
				
                if ( XMLHttpRequestObject2.readyState == 4 && 
                        XMLHttpRequestObject2.status == 200 )
                {
					document.getElementById("rss_div").innerHTML = XMLHttpRequestObject2.responseText;
                }
            }
            XMLHttpRequestObject2.send(null);
        }		
	}