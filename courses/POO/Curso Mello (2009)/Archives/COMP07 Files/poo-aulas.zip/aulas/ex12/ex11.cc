#include "ex11.h"

int main(int argc, char *argv[]) {

	Teste *t = new Teste("abc");

	delete t;

	return 0;
}
