package org.aplicacao.teste;

public class Calculo {
	public static int soma(int a, int b) {
		return a + b;
	}
}
