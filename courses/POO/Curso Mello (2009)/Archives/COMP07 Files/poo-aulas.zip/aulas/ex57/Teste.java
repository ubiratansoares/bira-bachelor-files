import java.util.*;

public class Teste {
	public static void main(String args[]) {
		Vector v = new Vector();
		try {
			v.add(new Object()); 
			Object o = v.elementAt(5);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("teste depois de resolver o problema");
	}
}
