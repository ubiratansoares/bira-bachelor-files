package com.empresa.framework;

public class Calculo {
	public static int soma(int a, int b) {
		return a + b;
	}
}
