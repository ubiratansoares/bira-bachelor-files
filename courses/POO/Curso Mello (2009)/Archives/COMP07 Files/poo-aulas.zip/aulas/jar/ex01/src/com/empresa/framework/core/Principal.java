package com.empresa.framework.core;

public class Principal {
	public Principal() {}

	public void metodo() {
		Teste t = new Teste();
		t.teste();
	}
}
