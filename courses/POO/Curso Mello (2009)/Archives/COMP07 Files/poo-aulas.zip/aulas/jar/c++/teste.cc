#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {

	cout << "teste" << endl;

	return 0;
}
