package com.empresa.framework.core;

import com.empresa.framework.*;

public class Teste {

	public Teste() {}

	public void teste() {
		System.out.println(Calculo.soma(5,4));
	}
}
