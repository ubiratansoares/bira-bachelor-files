package br.usp.icmc.projeto01;

public class Projeto {
	public Projeto() {}
	public void metodo1() { System.out.println("teste"); }
	public static void main(String args[]) {
		Projeto p = new Projeto();
		p.metodo1();
	}
}
