package br.usp.icmc.teste;

public class Abc {
	public Abc() {}
	public void metodo() {
		System.out.println("sou o metodo da Abc");
	}
}
