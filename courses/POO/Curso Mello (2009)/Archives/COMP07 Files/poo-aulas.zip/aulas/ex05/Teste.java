public class Teste {

	public static void main(String args[]) throws Exception {
		int i = System.in.read();
		System.out.println("valor = "+i);
	}
}
