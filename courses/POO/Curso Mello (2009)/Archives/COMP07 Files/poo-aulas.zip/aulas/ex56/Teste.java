import java.util.*;

public class Teste {
	public static void main(String args[]) {
		Vector v = null;
		try {
			System.out.println("teste antes do problema");
			v.add(new Object()); //pau
			System.out.println("teste depois do problema");
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("teste depois de resolver o problema");
	}
}
