import java.applet.*;
import java.awt.*;

public class Primeiro extends Applet {
	public Primeiro() { super(); }

	public void paint(Graphics g) {
		g.drawLine(0, 0, 100, 100);
	}
}
