import javax.swing.*;
import java.awt.*;

public class Segundo extends JApplet {
	public Segundo() { super(); }

	public void paint(Graphics g) {
		g.drawLine(0, 0, 100, 100);
		g.drawString("teste", 50, 50);
	}
}
