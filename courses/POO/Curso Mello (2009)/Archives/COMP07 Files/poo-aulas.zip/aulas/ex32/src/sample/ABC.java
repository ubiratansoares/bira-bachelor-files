package sample;

public class ABC {

	public ABC() {}

	public int soma(int a, int b) { 
		System.out.println("soma@int@int"); return a + b; }
	public float soma(float a, float b) { 
		System.out.println("soma@float@float"); return a + b; }
//	public double soma(double a, double b) { 
//		System.out.println("soma@double@double"); return a + b; }
//	public double soma(int a, double b) { 
//		System.out.println("soma@int@double"); return a + b; }
//	public double soma(double a, int b) { 
//		System.out.println("soma@double@int"); return a + b; }

	public static void main(String args[]) {
		ABC abc = new ABC();
		int a = 5;
		int b = 8;

		System.out.println(abc.soma(a, b));

//		System.out.println(abc.soma(1, 2));
//		System.out.println(abc.soma(1.2, 2.3));
//		System.out.println(abc.soma(1.2F, 2.3F));
//		System.out.println(abc.soma(1, 3.4));
//		System.out.println(abc.soma(3.4, 1));
	}
}
