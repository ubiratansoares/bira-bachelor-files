public class ADSL extends NetworkingConnection {
	public void disconnect() { System.out.println("dis"); }
	public void connect() { System.out.println("con"); }
}
