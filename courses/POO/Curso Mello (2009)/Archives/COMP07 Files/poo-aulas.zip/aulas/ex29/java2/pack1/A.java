package pack1;

public class A {
	private int a = 1;
	protected int b = 2;
	public int c = 3;
	int d = 4; // sem modificador -> package
}

