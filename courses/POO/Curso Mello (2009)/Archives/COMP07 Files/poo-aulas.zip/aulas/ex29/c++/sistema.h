#ifndef _SISTEMA_H_
#define _SISTEMA_H_
#include <iostream>
using namespace std;
class A {
	private: // somente objetos da propria classe
		int a;
	protected: // filhos, netos, bisnetos etc
		int b;
	public: // todos
		int c;
};
class B {
	public:
		void teste() {
			A a;
			//cout << a.a << endl;
			//cout << a.b << endl;
			cout << a.c << endl;
		}
};
#endif
