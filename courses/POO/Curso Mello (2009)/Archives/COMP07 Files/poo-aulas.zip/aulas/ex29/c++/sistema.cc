#include "sistema.h"

int main(int argc, char *argv[]) {
	B b;

	b.teste();

	return 0;
}
