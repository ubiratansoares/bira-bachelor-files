public interface B {
	public void run();
}
