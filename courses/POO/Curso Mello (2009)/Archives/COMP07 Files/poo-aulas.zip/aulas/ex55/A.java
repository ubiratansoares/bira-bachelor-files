public interface A {
	public void run();
}
