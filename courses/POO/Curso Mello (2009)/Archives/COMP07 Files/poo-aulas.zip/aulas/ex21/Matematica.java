public class Matematica {
	// todas as vezes que utilizamos static, estamos
	// criando uma vari�vel ou m�todo da classe
	//
	// se � algo da classe, preciso de objeto para acessar? NAUMMMMMM
	public static int soma(int a, int b) {
		return a + b;
	}

	public void main(String args[]) {
		/*
		Matematica m = new Matematica();
		int a = m.soma(5, 4);
		System.out.println(a);
		*/
		int a = Matematica.soma(5, 4);
		System.out.println(a);
	}
}
