public class Teste {
	public Teste() {

	}

	public void abc() {
		int a = Matematica.soma(5,4);
		System.out.println(a);
	}

	public static void main(String args[]) {
		Teste t = new Teste();
		t.abc();
	}
}
