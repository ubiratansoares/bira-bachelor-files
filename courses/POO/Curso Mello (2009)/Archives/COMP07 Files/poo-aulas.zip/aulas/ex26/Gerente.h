#ifndef _GERENTE_H_
#define _GERENTE_H_

#include "Funcionario.h"
#include <iostream>
using namespace std;

class Gerente: public virtual Funcionario {
	public:
		void test() {
			cout << "Sou o gerente" << endl;
		}
};

#endif
