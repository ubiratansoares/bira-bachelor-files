#ifndef _FUNCIONARIO_H_
#define _FUNCIONARIO_H_

#include <iostream>
using namespace std;

class Funcionario {
	public:
		void hello() {
			cout << "Sou o funcionario" << endl;
		}
};

#endif
