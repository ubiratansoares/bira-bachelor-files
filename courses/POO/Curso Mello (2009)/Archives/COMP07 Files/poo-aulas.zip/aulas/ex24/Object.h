#ifndef _OBJECT_H_
#define _OBJECT_H_

#include <iostream>

using namespace std;

class Object {

};

#endif
