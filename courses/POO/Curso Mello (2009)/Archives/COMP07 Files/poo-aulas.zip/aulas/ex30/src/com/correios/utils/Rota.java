package com.correios.utils;

public class Rota {
	public void print() {
		System.out.println("Rota do utils");
	}
}
