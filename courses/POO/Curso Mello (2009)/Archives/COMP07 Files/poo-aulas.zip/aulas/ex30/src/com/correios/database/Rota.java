package com.correios.database;

public class Rota {
	public void print() {
		System.out.println("Sou a rota do database");
	}
}
