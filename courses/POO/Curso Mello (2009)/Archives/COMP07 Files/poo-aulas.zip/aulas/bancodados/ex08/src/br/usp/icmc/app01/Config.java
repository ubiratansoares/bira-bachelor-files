package br.usp.icmc.app01;

public interface Config {
	String driver = "org.postgresql.Driver";
	String url = "jdbc:postgresql://localhost:5432/test01db";
	String username = "testuser";
	String password = "testpass";
}
