/*
 * $Id: noop.sql,v 1.1 2007/08/09 03:28:37 unsaved Exp $
 *
 * Simplest test possible.  Does absolutely nothing.
 */
