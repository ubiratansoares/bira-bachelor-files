/*
 * $Id: goodsqlonly.sql,v 1.1 2007/08/09 03:28:36 unsaved Exp $
 *
 * Just runs some successful SQL.
 */

CREATE TABLE t(i INTEGER);
