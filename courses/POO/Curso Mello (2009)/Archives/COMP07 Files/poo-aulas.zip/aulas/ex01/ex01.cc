#include "ex01.h"

int main(int argc, char *argv[]) {

	Celular c;

	c.talk();
	c.cancel();

	return 0;
}
