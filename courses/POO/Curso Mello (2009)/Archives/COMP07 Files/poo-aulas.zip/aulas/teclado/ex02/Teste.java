import java.io.*;

public class Teste {
	public static void main(String args[]) throws Exception {
		InputStreamReader isr = new InputStreamReader(System.in); 
		BufferedReader br = new BufferedReader(isr);
		System.out.println(br.readLine());
	}
}
