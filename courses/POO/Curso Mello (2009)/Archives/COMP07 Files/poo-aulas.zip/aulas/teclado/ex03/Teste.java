import java.util.*;

public class Teste {

	public static void main(String args[]) {
		Scanner s = new Scanner(System.in);

		int a = s.nextInt();
		double b = s.nextDouble();
		String c = s.next();

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
}
