public class Teste {
	public static void main(String args[]) throws Exception {
		int a = System.in.read();
		System.out.println(a);
	}
}
