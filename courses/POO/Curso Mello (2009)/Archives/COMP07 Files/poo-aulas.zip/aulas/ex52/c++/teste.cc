#include "teste.h"

int main(int argc, char *argv[]) {
	Teste2 t2;

	t2.metodo1();

	return 0;
}
