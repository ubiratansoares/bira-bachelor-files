#include "c.h"

int main(int argc, char *argv[]) {
	C c;

	c.m1();

	return 0;
}
