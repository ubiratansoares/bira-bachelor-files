#include <iostream>
#include <string.h>

using namespace std;

int main(int argc, char *argv[]) {
	char *p;

	//p = malloc(4);
	p = new char[4];

	//p = "Alo"; // erro!
	strcpy(p, "Alo");

	cout << p << endl;

	free(p);

	return 0;
}
