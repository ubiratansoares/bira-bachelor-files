#include <iostream>

using namespace std;

class Demo {
	char Nome[20];
	public:
		Demo ( const char *msg );
		~Demo ();
};
