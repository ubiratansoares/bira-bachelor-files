#include <iostream>

using namespace std;

int main(int argc, char *argv[]) {
	int var;

	cin >> var;
	cout << "valor = " << var << endl;
	cerr << "erro" << endl;

	return 0;
}
