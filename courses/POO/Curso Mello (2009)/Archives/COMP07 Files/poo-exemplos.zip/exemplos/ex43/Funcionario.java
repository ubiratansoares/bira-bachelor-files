public class Funcionario extends Pessoa {
	double salario;

	public Funcionario(String nome, double salario) {
		super(nome);
		this.salario = salario;
	}

	public void print() {
		System.out.println(this.nome+" "+this.salario);
	}

	public static void main(String args[]) {
		Funcionario f = new Funcionario("Jo�o", 123.23);
		Pessoa p = null;

		p = f;

		p.print();
	}
}
