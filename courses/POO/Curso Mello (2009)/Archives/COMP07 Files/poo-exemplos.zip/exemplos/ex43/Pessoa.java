public class Pessoa {
	String nome;

	public Pessoa(String nome) {
		this.nome = nome;
	}

	public void print() {
		System.out.println(this.nome);
	}
}
