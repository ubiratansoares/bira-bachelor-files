#include "ex42.h"

int main(int argc, char *argv[]) {
	Vetor *v = new Vetor(5);

	v->set(0, 1);
	v->set(1, 2);
	v->set(2, 3);
	v->set(3, 4);
	v->set(4, 5);

	v->print();

	Vetor *v2 = new Vetor(3);

	v2->set(0, 10);
	v2->set(1, 20);
	v2->set(2, 30);

	v2->print();

	v2 = v; // operator =

	v2->print();

	cout << endl;

	Vetor *v3 = v2; // construtor de c�pia
	v3->print();

	return 0;
}
