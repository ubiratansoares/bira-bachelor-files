public class Escopo {
	public static void main(String args[]) {
	
		int v = 10;

		{
			int v = 20;
		}
	}
}
