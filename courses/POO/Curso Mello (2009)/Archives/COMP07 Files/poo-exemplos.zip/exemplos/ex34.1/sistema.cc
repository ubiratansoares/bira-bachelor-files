#include "sistema.h"

int main(int argc, char *argv[]) {
	Pessoa *p = new Pessoa("123", "Nome01");

	cout << "Cpf: " << p->getCpf() << " Nome: " << p->getNome() << endl;

	Vendedor *v = new Vendedor("567", "Nome02");

	cout << "Cpf: " << v->getCpf() << " Nome: " << v->getNome() << endl;

	return 0;
}
