#include "ex33.h"

int main(int argc, char *argv[]) {
	Gerente *g = new Gerente("Jo�o", 10.23);
	g->testarAcesso();
}
