#include <iostream>

using namespace std;

class Teste {
	public:
		void funcao(int i);
};
