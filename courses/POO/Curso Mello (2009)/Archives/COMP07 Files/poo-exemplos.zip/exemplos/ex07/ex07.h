#include <iostream>

using namespace std;

class Teste {
	private:
		static int var;
	public:
		void funcao();
};
