public class Teste {

	public void m1() {
		System.out.println("m1()");
	}

	public void m1(int i) {
		System.out.println("m1(int)");
	}

	public void m1(long i) {
		System.out.println("m1(long)");
	}

	public void m1(float i) {
		System.out.println("m1(float)");
	}

	public void m1(double i) {
		System.out.println("m1(double)");
	}

	public void m1(double i, int b, String a) {
		System.out.println("m1(double, int, String)");
	}

	public static void main(String args[]) {
		
		Teste t = new Teste();
		t.m1();
		t.m1(1);
		t.m1(1.2);
		t.m1(1.2F);
		t.m1(1L);
		t.m1(1.2, 1, "abc");
	}
}
