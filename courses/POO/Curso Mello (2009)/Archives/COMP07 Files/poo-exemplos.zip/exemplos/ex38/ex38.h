#include <iostream>

using namespace std;

class X {
	public:
		void solicitacao(char *msg, int *i) {
			cout << msg;
			cin >> *i;
		}
		void solicitacao(char *msg, float *i) {
			cout << msg;
			cin >> *i;
		}
		void solicitacao(char *msg, long *i) {
			cout << msg;
			cin >> *i;
		}

};
