#include "ex35.h"

int main(int argc, char *argv[]) {
	Funcionario *f = new Funcionario("Jo�o", 123.22);
	//funcao(f);
	f->teste();
}
