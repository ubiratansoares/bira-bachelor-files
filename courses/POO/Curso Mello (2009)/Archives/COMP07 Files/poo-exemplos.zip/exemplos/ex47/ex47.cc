#include "ex47.h"

int main(int argc, char *argv[]) {
	TesteFilha *tf = new TesteFilha();
	tf->teste();
	tf->testeForcando();

	return 0;
}
