#include "ex48.h"

int main(int argc, char *argv[]) {
	//Item *i = new Item(2, "Item 2");

	Livro *l = new Livro(1, "Livro 1", "Isbn 1");
	cout << l->getAllInformation() << endl;

	return 0;
}
