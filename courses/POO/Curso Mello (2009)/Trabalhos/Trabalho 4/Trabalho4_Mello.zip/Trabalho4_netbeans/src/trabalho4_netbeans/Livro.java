package trabalho4_netbeans;

public class Livro extends Publicacao {
	private String isbn;

	public Livro(String titulo, String editora, String isbn) {
		super(titulo, editora);
		this.isbn = isbn;
	}
	public String print() {
        String saida = "\n";

        saida += "\nLivro";
        saida += "\n - Código    : " + this.codigo;
		saida += "\n - Título    : " + this.titulo;
		saida += "\n - Editora   : " + this.editora;
		saida += "\n - ISBN      : " + this.isbn;

        return saida;
    }
}
