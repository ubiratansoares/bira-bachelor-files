package trabalho4_netbeans;

public abstract class Midia extends Item {
	protected String gravadora;

	public Midia(String titulo, String gravadora) {
		super(titulo); // const do pai
		this.gravadora = gravadora;
	}
	public abstract String print();
}