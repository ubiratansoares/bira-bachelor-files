package trabalho4_netbeans;

public abstract class Publicacao extends Item {
	protected String editora;

	public Publicacao(String titulo, String editora) {
		super(titulo); // const do pai
		this.editora = editora;
	}
	public abstract String print();
}
