package trabalho4_netbeans;

public class Revista extends Publicacao {
	private int edicao;

	public Revista(String titulo, String editora, int edicao) {
		super(titulo, editora);
		this.edicao = edicao;
	}
	public String print() {
        String saida = "\n";

        saida += "\nRevista";
        saida += "\n - Código    : " + this.codigo;
		saida += "\n - Título    : " + this.titulo;
		saida += "\n - Editora   : " + this.editora;
		saida += "\n - Edição    : " + this.edicao;

        return saida;
	}
}