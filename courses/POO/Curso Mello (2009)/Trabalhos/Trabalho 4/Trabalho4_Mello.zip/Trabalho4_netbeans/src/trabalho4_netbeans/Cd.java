package trabalho4_netbeans;

public class Cd extends Midia {
	private String autor;

	public Cd(String titulo, String editora, String autor) {
		super(titulo, editora);
		this.autor = autor;
	}
	public String print() {
        String saida = "\n";

        saida += "\nCD";
        saida += "\n - Código    : " + this.codigo;
		saida += "\n - Título    : " + this.titulo;
		saida += "\n - Gravadora : " + this.gravadora;
		saida += "\n - Autor     : " + this.autor;

        return saida;
	}
}