package trabalho4_netbeans;

public class Dvd extends Midia {
	private String tipo;

	public Dvd(String titulo, String editora, String tipo) {
		super(titulo, editora);
		this.tipo = tipo;
	}
	public String print() {
        String saida = "\n";

        saida += "\nDVD";
        saida += "\n - Código    : " + this.codigo;
		saida += "\n - Título    : " + this.titulo;
		saida += "\n - Gravadora : " + this.gravadora;
		saida += "\n - Tipo      : " + this.tipo;

        return saida;
    }
}