package trabalho4_netbeans;

public abstract class Item {
	protected int codigo;
	protected String titulo;

    private static int contador = 0;

	public Item(String titulo) {
		this.codigo = ++Item.contador;
		this.titulo = titulo;
	}

    public static int getContador(){return Item.contador;}

    public boolean isCodigo(int codigo) {
        return this.codigo == codigo;
    }

    public abstract String print();
}
