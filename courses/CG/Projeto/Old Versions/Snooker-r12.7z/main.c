#include	<stdlib.h>
#include	<stdio.h>
#include	<unistd.h>
#include	<time.h>
#include	<GL/gl.h>
#include	<GL/glu.h>
#include	<GL/glut.h>
#include	"Snooker.h"

#define	D_WINDOW_WIDTH				1000
#define	D_WINDOW_HEIGHT				486

#define D_LAYOUT_RIGHTBAR_WIDTH		300

#define D_TABLE_ASPECT				2.007311586051743532	// D_TABLE_ASPECT = D_TABLE_WIDTH / D_TABLE_HEIGHT
#define	D_TABLE_WIDTH				3.569
#define	D_TABLE_HEIGHT				1.778
#define	D_TABLE_TOTAL_WIDTH			3.769
#define	D_TABLE_TOTAL_HEIGHT		1.978

#define	D_BALLS						35
#define	D_BALL_RADIUS				0.02625
//#define	D_BALL_RADIUS				0.04
#define	D_BALL_MASS					1.0
#define	D_WHITE_BALL_RADIUS			0.034
//#define	D_WHITE_BALL_RADIUS			0.05
#define	D_WHITE_BALL_MASS			1.0

#define	D_STATE_STOPPED				0
#define	D_STATE_PREPARING			1
#define	D_STATE_RUNNING				2
#define	D_STATE_ENDED				3

float		timeRatio = 1.0;
PSnooker	snooker;
unsigned	fps = 0, state = D_STATE_STOPPED;
float		nowTime = 0, lastTime = 0, timeElapsed = 0, timeFPS = 0;

int proportion(int X1, int Y1, int X2) {
	return Y1 * X2 / X1;
}

void resize(int width, int height) {
	snookerSetTable2DBounds(snooker,uvertex(width - D_LAYOUT_RIGHTBAR_WIDTH,height - D_LAYOUT_RIGHTBAR_WIDTH / (int)D_TABLE_ASPECT),uvertex(D_LAYOUT_RIGHTBAR_WIDTH,D_LAYOUT_RIGHTBAR_WIDTH / (int)D_TABLE_ASPECT));
}

void display(void) {

	nowTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
	timeElapsed = nowTime - lastTime;
	lastTime = nowTime;
	timeFPS += timeElapsed;
	fps++;

	if ( state == D_STATE_RUNNING && !snookerIsPaused(snooker) ) {
		if ( timeFPS > 1.0 ) {
			timeFPS = 0;
			fps = 0;
		}
		snookerThink(snooker,timeElapsed / timeRatio);
		if ( !snookerMovementInProgress(snooker) ) {
//			snookerPause(snooker,1);
			if ( snookerGameEnded(snooker) ) {
				state = D_STATE_ENDED;
				printf("> Game Over!\n");
			} else {
				state = D_STATE_STOPPED;
			}
		}
	}

	// rendering.
//	glClear(GL_COLOR_BUFFER_BIT);

	snookerPaint2D(snooker);

	glutSwapBuffers();
}


void key(unsigned char key, int x, int y) {
	if ( key == ' ' ) {
		if ( snookerIsPaused(snooker) ) {
			snookerPause(snooker,0);
		} else {
			snookerPause(snooker,1);
		}
		lastTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
	} else if ( key == 's' ) {
		timeRatio += 0.1;
	} else if ( key == 'f' ) {
		if ( timeRatio > 0.1 ) {
			timeRatio -= 0.1;
		}
	} else if ( key == 'q' && state == D_STATE_STOPPED ) {
		snookerTackleRandomBall(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'w' && state == D_STATE_STOPPED ) {
		snookerTackleClosestBall(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'e' && state == D_STATE_STOPPED ) {
		snookerTackleFartestBall(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'r' && state == D_STATE_STOPPED ) {
		snookerTackleRandom(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'v' ) {
		if ( ballGetFlag(snookerGetWhiteBall(snooker),BALL_DRAW_SPEED_VECTOR) ) {
			snookerClearBallFlag(snooker,-1,BALL_DRAW_SPEED_VECTOR);
		} else {
			snookerSetBallFlag(snooker,-1,BALL_DRAW_SPEED_VECTOR);
		}
	}
	glutPostRedisplay();
}

void idle(void) {
	if ( snookerIsPaused(snooker) ) {
		usleep(50000);
	} else if ( !snookerMovementInProgress(snooker) ) {
		usleep(10000);
		lastTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
	} else {
		glutPostRedisplay();
	}
}

int main(int argc, char *argv[]) {

	printf("> Keys:\n");
	printf("  s       reduz a velocidade do tempo.\n");
	printf("  f       aumenta a velocidade do tempo.\n");
	printf("  v       liga/desliga o desenho dos vetores velocidade.\n");
	printf("  espaco  pause.\n");
	printf("  r       tacada aleatoria\n");
	printf("  e       tacada na bola mais distante da bola branca.\n");
	printf("  w       tacada na bola mais proxima da bola branca.\n");
	printf("  q       tacada em uma bola aleatoria qualquer.\n\n");

	#ifndef DISABLE_RANDSEED
		srand(time(0));
	#endif

    glutInit(&argc, argv);
    glutInitWindowSize(D_WINDOW_WIDTH,D_WINDOW_HEIGHT);
    glutInitWindowPosition(0,0);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);

    glutCreateWindow("Snooker");

    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutKeyboardFunc(key);
    glutIdleFunc(idle);

    glClearColor(0,0,0,0);

	// prepare the game.
	snooker = snookerCreate();
	snookerSetupTable(snooker,D_TABLE_TOTAL_WIDTH,D_TABLE_TOTAL_HEIGHT,D_TABLE_WIDTH,D_TABLE_HEIGHT,D_WHITE_BALL_RADIUS * 2.2,0.00017);
	snookerSetupBalls(snooker,D_BALLS,D_BALL_RADIUS,D_BALL_MASS);
	snookerSetupWhiteBall(snooker,D_WHITE_BALL_RADIUS,D_WHITE_BALL_MASS);
	snookerPause(snooker,0);
//	snookerSetTable2DBounds(snooker,uvertex(0,0),uvertex(D_WINDOW_WIDTH,D_WINDOW_HEIGHT));

	// Enable AA.
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_POLYGON_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

    glutMainLoop();

    return EXIT_SUCCESS;
}
