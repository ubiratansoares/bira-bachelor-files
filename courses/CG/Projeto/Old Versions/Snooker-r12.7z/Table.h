#ifndef TABLE_H_INCLUDED
#define TABLE_H_INCLUDED

#include	"SnookerDefs.h"
#include	"SnookerUtils.h"
#include	"Ball.h"
#include	"Line.h"

#define		TABLE_BOUNDS	24

typedef struct {
	TUVertex	position2D, dimension2D;					// 2D positioning and dimensioning.
	TUVertex	position3D, dimension3D;					// 3D positioning and dimensioning.
	TFloat		width, height, worldWidth, worldHeight;
	TFloat		pocketSize, atrCoef;
	PLine		bounds[TABLE_BOUNDS];
	unsigned	pockets;
} TTable, *PTable;

PTable	tableCreate(TFloat worldWidth, TFloat worldHeight);
void	tableSet2DBounds(PTable table, TUVertex p, TUVertex d);
void	tableSet3DBounds(PTable table, TUVertex p, TUVertex d);
void	tableDestroy(PTable *table);
void	tableSetup(PTable table, TFloat width, TFloat height, TFloat pocketSize, TFloat atrCoef);
void	tablePaint2D(PTable t);
int		tableCollided(PTable, PBall);
int		tableCollision(PTable table, PBall ball, int hit);
TFloat	tableCollisionTime(PTable table, PBall ball, int hit);
TFloat	tableGetBorder(PTable table);
TFloat	tableGetAtrCoef(PTable table);
int		tableInPocket(PTable table, PBall ball, int hit);

#endif // TABLE_H_INCLUDED
