#include <stdlib.h>
#include <math.h>
#include <GL/gl.h>
#include "Table.h"

PTable tableCreate(TFloat totalWidth, TFloat totalHeight) {
	PTable table = malloc(sizeof(TTable));
	table->totalWidth = totalWidth;
	table->totalHeight = totalHeight;
	return table;
}

void tableSetup(PTable table, TFloat width, TFloat height, TFloat pocketSize, TFloat atrCoef) {
	table->width = width;
	table->height = height;
	table->pocketSize = pocketSize;
	table->atrCoef = atrCoef;
}

void tableDestroy(PTable *table) {
	if ( table && *table ) {
		free(*table);
		*table = 0;
	}
}

void tablePaint(PTable t) {
	TFloat	border = tableGetBorder(t);
	glLoadIdentity();

	glColor3f(0.34,0.18,0.13);
	glBegin(GL_QUADS);
		glVertex2f(0,0);
		glVertex2f(0,t->totalHeight);
		glVertex2f(t->totalWidth,t->totalHeight);
		glVertex2f(t->totalWidth,0);
	glEnd();

	glColor3f(0.0,0.4,0.0);
	glBegin(GL_QUADS);
		glVertex2f(border,border);
		glVertex2f(border,t->height + border);
		glVertex2f(t->width + border,t->height + border);
		glVertex2f(t->width + border,border);
	glEnd();

	TFloat	slice = t->pocketSize / M_SQRT_2;
	TFloat	recoil = slice;
	glBegin(GL_QUADS);
		glVertex2f(border + slice						,border);
		glVertex2f(border								,border + slice);
		glVertex2f(border - recoil						,border + slice - recoil);
		glVertex2f(border + slice - recoil				,border - recoil);

		glVertex2f(border + slice						,t->height + border);
		glVertex2f(border								,t->height + border - slice);
		glVertex2f(border - recoil						,t->height + border + slice - recoil);
		glVertex2f(border + slice - recoil				,t->height + border + recoil);

		glVertex2f(t->width + border - slice			,t->height + border);
		glVertex2f(t->width + border					,t->height + border - slice);
		glVertex2f(t->width + border + recoil			,t->height + border + slice - recoil);
		glVertex2f(t->width + border - slice + recoil	,t->height + border + recoil);

		glVertex2f(t->width + border - slice			,border);
		glVertex2f(t->width + border					,border + slice);
		glVertex2f(t->width + border + recoil			,border + slice - recoil);
		glVertex2f(t->width + border - slice + recoil	,border - recoil);

		glVertex2f(t->width / 2.0 + border - M_SQRT_2 * 0.7 * slice,border);
		glVertex2f(t->width / 2.0 + border + M_SQRT_2 * 0.7 * slice,border);
		glVertex2f(t->width / 2.0 + border + M_SQRT_2 * 0.5 * slice,border - recoil);
		glVertex2f(t->width / 2.0 + border - M_SQRT_2 * 0.5 * slice,border - recoil);

		glVertex2f(t->totalWidth / 2.0 - M_SQRT_2 * 0.7 * slice,t->height + border);
		glVertex2f(t->totalWidth / 2.0 + M_SQRT_2 * 0.7 * slice,t->height + border);
		glVertex2f(t->totalWidth / 2.0 + M_SQRT_2 * 0.5 * slice,t->height + border + recoil);
		glVertex2f(t->totalWidth / 2.0 - M_SQRT_2 * 0.5 * slice,t->height + border + recoil);
	glEnd();

	glColor3f(0,0,0);
	slice /= 2.0;
	drawCircle(t->pocketSize / 2.0,border - M_COS_PI_4 * slice,border - M_SIN_PI_4 * slice);
	drawCircle(t->pocketSize / 2.0,border - M_COS_PI_4 * slice,t->height + border + M_SIN_PI_4 * slice);
	drawCircle(t->pocketSize / 2.0,t->width + border + M_COS_PI_4 * slice,t->height + border + M_SIN_PI_4 * slice);
	drawCircle(t->pocketSize / 2.0,t->width + border + M_COS_PI_4 * slice,border - M_SIN_PI_4 * slice);
	drawCircle(t->pocketSize / 2.0,t->totalWidth / 2.0,border - t->pocketSize / 2.0);
	drawCircle(t->pocketSize / 2.0,t->totalWidth / 2.0,t->height + border + t->pocketSize / 2.0);
}

int tableCollided(PTable table, PBall ball) {
	int	hit = 0;
	if ( ball->x - ball->radius <= 0 )
		hit = M_HIT_LEFT;
	else if ( ball->x + ball->radius >= table->width )
		hit = M_HIT_RIGHT;
	if ( ball->y - ball->radius <= 0 )
		hit |= M_HIT_BOTTOM;
	else if ( ball->y + ball->radius >= table->height)
		hit |= M_HIT_TOP;
	return hit;
}

TFloat tableCollisionTimeH(PTable table, PBall ball, TFloat vx, int hit) {
	TFloat	dx;
	if ( hit & M_HIT_LEFT ) {
		dx = ball->x;
	} else {
		dx = table->width - ball->x;
	}
	dx = ball->radius - dx;
	return dx / vx;
}

TFloat tableCollisionTimeV(PTable table, PBall ball, TFloat vy, int hit) {
	TFloat	dy;
	if ( hit & M_HIT_BOTTOM ) {
		dy = ball->y;
	} else {
		dy = table->height - ball->y;
	}
	dy = ball->radius - dy;
	return dy / vy;
}

TFloat tableCollisionTime(PTable table, PBall ball, int hit) {
	TFloat 	time = 0.0;
	TFloat	tx = 0.0, ty = 0.0;
	if ( hit & M_HIT_H ) {
		tx = tableCollisionTimeH(table,ball,ballSpeedX(ball),hit);
	}
	if ( hit & M_HIT_V ) {
		ty = tableCollisionTimeV(table,ball,ballSpeedY(ball),hit);
	}
	if ( tx == 0.0 ) {
		time = ty;
	} else if ( ty == 0.0 ) {
		time = tx;
	} else {
		time = ( tx >= ty ) ? ty : tx;
	}
	time = fabs(time);
	return time;
}

int tableCollision(PTable table, PBall ball, int hit) {
	if ( hit & M_HIT_LEFT ) {
		if ( ball->angle <= M_PI ) {
			ball->angle -= M_PI_2;
			ball->angle *= -1;
			ball->angle += M_PI_2;
		} else {
			ball->angle -= M_3_PI_2;
			ball->angle *= -1;
			ball->angle += M_3_PI_2;
		}
	}
	if ( hit & M_HIT_RIGHT ) {
		if ( ball->angle <= M_PI ) {
			ball->angle -= M_PI_2;
			ball->angle *= -1;
			ball->angle += M_PI_2;
		} else {
			ball->angle -= M_3_PI_2;
			ball->angle *= -1;
			ball->angle += M_3_PI_2;
		}
	}
	if ( hit & M_HIT_TOP ) {
		ball->angle = M_2_PI - ball->angle;
	}
	if ( hit & M_HIT_BOTTOM ) {
		ball->angle = M_2_PI - ball->angle;
	}
	ball->speed *= M_TABLE_HIT_SPEED_RATIO;
	return hit;
}

TFloat tableGetBorder(PTable table) {
	return (table->totalWidth - table->width) / 2.0;
}

TFloat tableGetAtrCoef(PTable table) {
	return table->atrCoef;
}
