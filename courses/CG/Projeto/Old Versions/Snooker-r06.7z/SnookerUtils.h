#ifndef SNOOKERUTILS_H_INCLUDED
#define SNOOKERUTILS_H_INCLUDED

#include "SnookerDefs.h"

void	drawCircle(TFloat radius, TFloat xc, TFloat yc);

#endif // SNOOKERUTILS_H_INCLUDED
