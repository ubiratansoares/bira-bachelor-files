#include	"SnookerUtils.h"
#include	"GL/gl.h"

void drawCircle(TFloat radius, TFloat xc, TFloat yc) {
	glBegin(GL_TRIANGLE_FAN);
		TFloat	x, y;
		TFloat	angle;
		for ( angle = 0; angle < M_2_PI; angle += 0.2 ) {
			x = xc + radius * cos(angle);
			y = yc + radius * sin(angle);
			glVertex2f(x,y);
		}
	glEnd();
}
