#include	"Snooker.h"

#define		D_CUEBALL	0

PSnooker snookerCreate() {
	PSnooker snooker = malloc(sizeof(TSnooker));
	snooker->paused = 1;
	snookerSetCameraMode(snooker,D_CAMERA_MODE_STATIC);
	snookerSetCameraPosition(snooker,0.0,0.0,D_TABLE_FLOOR_HEIGHT + 0.1);
	snookerSetCameraAngle(snooker,0);
	snookerSetCameraDistance(snooker,D_CAMERA_DISTANCE);
	snookerSetCameraHeight(snooker,D_CAMERA_HEIGHT);
	return snooker;
}

void snookerSetupTable(PSnooker snooker, TFloat totalWidth, TFloat totalHeight, TFloat width, TFloat height,
TFloat pocketSize, TFloat atrCoef) {
	snooker->table = tableCreate(totalWidth,totalHeight);
	tableSetup(snooker->table,width,height,pocketSize,atrCoef);
}

void snookerSetupBalls(PSnooker snooker, unsigned balls, TFloat radius, TFloat mass) {
	snooker->balls = balls;
	snooker->ball = (PBall*)malloc(sizeof(PBall) * balls);
	unsigned	i = 0;
	for ( i = 0; i < balls; i++ ) {
		snooker->ball[i] = ballCreate("");
		ballSetup(snooker->ball[i],radius,mass);
		ballSetColor(snooker->ball[i],rand() / (TFloat)RAND_MAX,rand() / (TFloat)RAND_MAX,rand() / (TFloat)RAND_MAX);
		ballSetXY(snooker->ball[i],(i + 1) * snooker->table->width / (balls + 1),snooker->table->height / 2.0);
		ballApplyMovement(snooker->ball[i],0.0,0.0);
	}
}

void snookerSetupCueBall(PSnooker snooker, TFloat radius, TFloat mass) {
	ballSetup(snookerGetCueBall(snooker),radius,mass);
	ballSetColor(snookerGetCueBall(snooker),1.0,1.0,1.0);
}

void snookerDestroy(PSnooker *snkr) {
	PSnooker snooker = *snkr;
	int	i;
	for ( i = 0; i < snooker->balls; i++ ) {
		ballDestroy(&(snooker->ball[i]));
	}
	free(snooker->ball);
	tableDestroy(&(snooker->table));
	free(snooker);
	*snkr = 0;
}

void snookerSetTable2DBounds(PSnooker snooker, TUVertex p, TUVertex d) {
	snooker->position2D = p;
	snooker->dimension2D = d;
}

void snookerSetTable3DBounds(PSnooker snooker, TUVertex p, TUVertex d) {
	snooker->position3D = p;
	snooker->dimension3D = d;
}

PBall snookerGetCueBall(PSnooker snooker) {
	return snooker->ball[D_CUEBALL];
}

unsigned snookerGetBalls(PSnooker snooker) {
	return snooker->balls;
}

PBall snookerGetBall(PSnooker snooker, unsigned ball) {
	return snooker->ball[ball];
}

void snookerPaint2D(PSnooker snooker) {
	// prepare the projection and the modelview.
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(snooker->position2D.x,snooker->position2D.y,snooker->dimension2D.x,snooker->dimension2D.y);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0.0,tableGetTotalWidth(snooker->table),0.0,tableGetTotalHeight(snooker->table),-1.0,1.0);

	glMatrixMode(GL_MODELVIEW);

	// paint.
	unsigned	i;
	TFloat		border = tableGetBorder(snooker->table);
	tablePaint2D(snooker->table);
	for ( i = 0; i < snooker->balls; i++ ) {
		if ( !ballGetFlag(snooker->ball[i],BALL_DEAD) ) {
			ballPaint2D(snooker->ball[i],border);
		}
	}
}

void snookerPaint3D(PSnooker snooker) {
	// prepare the projection and the modelview.
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glViewport(snooker->position3D.x,snooker->position3D.y,snooker->dimension3D.x,snooker->dimension3D.y);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(60.0,(TFloat)snooker->dimension3D.x / (TFloat)snooker->dimension3D.y,0.1,10.0);

	glMatrixMode(GL_MODELVIEW);
	if ( snooker->camera.mode == D_CAMERA_MODE_STATIC ) {
		gluLookAt(snooker->camera.x,snooker->camera.y,snooker->camera.z,
			1.8,0.8,D_TABLE_FLOOR_HEIGHT,
			0,0,1);
	}

	// paint.
	unsigned	i;
	TFloat		border = tableGetBorder(snooker->table);
	tablePaint3D(snooker->table);
	for ( i = 0; i < snooker->balls; i++ ) {
		if ( !ballGetFlag(snooker->ball[i],BALL_DEAD) ) {
			ballPaint3D(snooker->ball[i],border);
		}
	}
}

void snookerStepBalls(PSnooker snooker, TFloat time) {
	#ifdef DEBUG
		printf("\nsnookerStepBalls(snooker,%.6f)",time);
	#endif
	int		i;
	TFloat	m = tableGetAtrCoef(snooker->table);
	for ( i = 0; i < snooker->balls; i++ ) {
		if ( !ballGetFlag(snooker->ball[i],BALL_DEAD) ) {
			#ifdef DEBUG
				printf("  %d ",i);
			#endif
			ballStep(snooker->ball[i],m,time);
		}
	}
}

void snookerThink(PSnooker snooker, TFloat timeElapsed) {

	if ( timeElapsed <= 0.0 ) {
		return;
	}

	if ( timeElapsed > D_SNOOKER_THINK_MAX_TIME_SLICE ) {
		#ifdef DEBUG
			puts("- Splitting timeElapsed!");
		#endif
		timeElapsed -= D_SNOOKER_THINK_MAX_TIME_SLICE;
		snookerThink(snooker,timeElapsed);
		#ifdef DEBUG
			puts("- Split Done!");
		#endif
	}

	PTable	table = snooker->table;
	PBall	*ball = snooker->ball;
	int		balls = snooker->balls, i, j, hit;

	do {

		#ifdef DEBUG
			printf("\n> snookerThink(snooker,%.6f)\n",timeElapsed);
		#endif

		// move balls to the position so we can calculate if any ball collided with anything.
		snookerStepBalls(snooker,timeElapsed);

		#ifdef DEBUG
			puts("\n> Testing Hit");
		#endif

		hit = 0;

		TFloat		time = 0.0;
		int			hitWithTable = 1, hitTableBound = 0;
		unsigned	hitBall1 = 0, hitBall2 = 0;

		// check if any ball collided with the table.
		for ( i = 0; i < balls; i++ ) {
			if ( !ballGetFlag(ball[i],BALL_DEAD) && ballSpeed(ball[i]) != 0 ) {
				// a collision happened? How was this collision?
				int	tempHitTableBound = tableCollided(table,ball[i]);
				if ( tempHitTableBound ) {
					#ifdef DEBUG
						puts("  - Collision Detected");
						printf("    ball=%u hitTableBound=%u X=%.6f Y=%.6f R=%.6f\n",i,tempHitTableBound,ball[i]->x,ball[i]->y,ball[i]->radius);
					#endif
					// get the actual time of the collision.
					TFloat	timeTemp = tableCollisionTime(table,ball[i],tempHitTableBound);
					if ( timeTemp > time ) {
						time = timeTemp;
						hitTableBound = tempHitTableBound;
						hitWithTable = 1;
						hitBall1 = i;
						hit = 1;
						#ifdef DEBUG
							puts("  - Previous Collision Detected: Table");
							printf("    time=%.6f ball=%u hitTableType=%u X=%.6f Y=%.6f R=%.6f\n",time,hitBall1,hitTableBound,ball[i]->x,ball[i]->y,ball[i]->radius);
						#endif
					}
				}
			}
		}

		// check if collided with another ball.
		for ( i = 0; i < balls - 1; i++ ) {
			if ( !ballGetFlag(ball[i],BALL_DEAD) ) {
				for ( j = i + 1; j < balls; j++ ) {
					if ( !ballGetFlag(ball[j],BALL_DEAD) ) {
						// a collision happened?
						if ( ballCollided(ball[i],ball[j]) ) {
							// get the actual time of the collision.
							TFloat	timeTemp = ballCollisionTime(ball[i],ball[j]);
							if ( timeTemp > time ) {
								time = timeTemp;
								hitWithTable = 0;
								hitBall1 = i;
								hitBall2 = j;
								hit = 1;
								#ifdef DEBUG
									puts("  - Collision Detected: Balls");
									printf("    time=%.6f balls=(%u,%u)\n",time,hitBall1,hitBall2);
								#endif
							}
						}
					}
				}
			}
		}

		// if anything collided.
		if ( hit ) {
			// re-calculate the timeElapsed.
			timeElapsed -= time;
			#ifdef DEBUG
				if ( !hitWithTable ) {
					printf("  D=%.3f\n",ballDistance(snooker->ball[hitBall1],snooker->ball[hitBall2]));
				}
			#endif
			// step every ball to the exactly moment the collision happened.
			snookerStepBalls(snooker,-time);
			#ifdef DEBUG
				printf("  time=%.6f timeElapsed=%.6f\n",time,timeElapsed);
			#endif
			// apply the collision.
			if ( hitWithTable ) {
				if ( tableInPocket(snooker->table,snooker->ball[hitBall1],hitTableBound) ) {
					#ifdef	DEBUG
						printf("- Pocket Hit: %u\n",hitBall1);
					#endif
					ballSetFlag(snooker->ball[hitBall1],BALL_DEAD);
				} else {
					#ifdef DEBUG
						puts("- Table Hit");
						printf("  B=%u X=%.6f Y=%.6f A=%.3f V=%.3f\n",hitBall1,snooker->ball[hitBall1]->x,snooker->ball[hitBall1]->y,snooker->ball[hitBall1]->angle,snooker->ball[hitBall1]->speed);
					#endif
					tableCollision(snooker->table,snooker->ball[hitBall1],hitTableBound);
					#ifdef DEBUG
						printf("  A=%.3f V=%.3f\n",snooker->ball[hitBall1]->angle,snooker->ball[hitBall1]->speed);
					#endif
				}
			} else {
				#ifdef DEBUG
					puts("- Ball Hit");
					printf("  D=%.3f\n",ballDistance(snooker->ball[hitBall1],snooker->ball[hitBall2]));
					printf("  B=%u X=%.3f Y=%.3f A=%.3f V=%.3f\n",hitBall1,snooker->ball[hitBall1]->x,snooker->ball[hitBall1]->y,snooker->ball[hitBall1]->angle,snooker->ball[hitBall1]->speed);
					printf("  B=%u X=%.3f Y=%.3f A=%.3f V=%.3f\n",hitBall2,snooker->ball[hitBall2]->x,snooker->ball[hitBall2]->y,snooker->ball[hitBall2]->angle,snooker->ball[hitBall2]->speed);
				#endif
				ballCollision(snooker->ball[hitBall1],snooker->ball[hitBall2]);
				#ifdef DEBUG
					printf("  B=%u X=%.3f Y=%.3f A=%.3f V=%.3f\n",hitBall1,snooker->ball[hitBall1]->x,snooker->ball[hitBall1]->y,snooker->ball[hitBall1]->angle,snooker->ball[hitBall1]->speed);
					printf("  B=%u X=%.3f Y=%.3f A=%.3f V=%.3f\n",hitBall2,snooker->ball[hitBall2]->x,snooker->ball[hitBall2]->y,snooker->ball[hitBall2]->angle,snooker->ball[hitBall2]->speed);
				#endif
			}
		}

	} while ( hit );

}

int snookerIsPaused(PSnooker snooker) {
	return snooker->paused;
}

void snookerPause(PSnooker snooker, int pause) {
	snooker->paused = pause;
	if ( !snooker->paused ) {
		int	i;
		for ( i = 0; i < snooker->balls; i++ ) {
			ballClearFlag(snooker->ball[i],BALL_DRAW_ERROR_SIGNAL);
		}
	}
}

void snookerSetBallFlag(PSnooker snooker, int ball, unsigned flag) {
	if ( ball >= 0 ) {
		ballSetFlag(snooker->ball[ball],flag);
	} else {
		for ( ball = 0; ball < snooker->balls; ball++ ) {
			ballSetFlag(snooker->ball[ball],flag);
		}
	}
}

void snookerClearBallFlag(PSnooker snooker, int ball, unsigned flag) {
	if ( ball >= 0 ) {
		ballClearFlag(snooker->ball[ball],flag);
	} else {
		for ( ball = 0; ball < snooker->balls; ball++ ) {
			ballClearFlag(snooker->ball[ball],flag);
		}
	}
}

int snookerMovementInProgress(PSnooker snooker) {
	int	i, prog = 0;
	for ( i = 0; i < snooker->balls; i++ ) {
		if ( ballSpeed(snooker->ball[i]) != 0.0 && !ballGetFlag(snooker->ball[i],BALL_DEAD) ) {
			prog = 1;
		}
	}
	return prog;
}

int snookerGameEnded(PSnooker snooker) {
	int	i;
	for ( i = 0; i < snooker->balls; i++ ) {
		if ( snooker->ball[i] != snookerGetCueBall(snooker) && !ballGetFlag(snooker->ball[i],BALL_DEAD) ) {
			return 0;
		}
	}
	return 1;
}

void snookerTackleRandomBall(PSnooker snooker, TFloat speed) {
	unsigned	iball = 0;
	PBall		wball = snookerGetCueBall(snooker), ball;
	do {
		iball = rand() % snooker->balls;
		ball = snooker->ball[iball];
	} while ( ball == wball && ballGetFlag(ball,BALL_DEAD) );
	TFloat	angle = atan(angularCoef(vertex(wball->x,wball->y),vertex(ball->x,ball->y)));
	if ( ball->x < wball->x ) {
		angle += D_PI;
	}
	if ( angle < 0 ) {
		angle += D_2_PI;
	} else if ( angle > D_2_PI ) {
		angle -= D_2_PI;
	}
	ballApplyMovement(wball,angle,speed);
}

void snookerTackleClosestBall(PSnooker snooker, TFloat speed) {
	unsigned	i, iball = 0;
	TFloat		d = 1000.0, t;
	PBall		wball = snookerGetCueBall(snooker), ball;
	for ( i = 0; i < snooker->balls; i++ ) {
		ball = snooker->ball[i];
		if ( ball != wball && !ballGetFlag(ball,BALL_DEAD) ) {
			t = distancePointToPoint(vertex(ball->x,ball->y),vertex(wball->x,wball->y));
			if ( t < d ) {
				d = t;
				iball = i;
			}
		}
	}
	ball = snooker->ball[iball];
	TFloat	angle = atan(angularCoef(vertex(wball->x,wball->y),vertex(ball->x,ball->y)));
	if ( ball->x < wball->x ) {
		angle += D_PI;
	}
	if ( angle < 0 ) {
		angle += D_2_PI;
	} else if ( angle > D_2_PI ) {
		angle -= D_2_PI;
	}
	ballApplyMovement(wball,angle,speed);
}

void snookerTackleFartestBall(PSnooker snooker, TFloat speed) {
	unsigned	i, iball = 0;
	TFloat		d = 0, t;
	PBall		wball = snookerGetCueBall(snooker), ball;
	for ( i = 0; i < snooker->balls; i++ ) {
		ball = snooker->ball[i];
		if ( ball != wball && !ballGetFlag(ball,BALL_DEAD) ) {
			t = distancePointToPoint(vertex(ball->x,ball->y),vertex(wball->x,wball->y));
			if ( t > d ) {
				d = t;
				iball = i;
			}
		}
	}
	ball = snooker->ball[iball];
	TFloat	angle = atan(angularCoef(vertex(wball->x,wball->y),vertex(ball->x,ball->y)));
	if ( ball->x < wball->x ) {
		angle += D_PI;
	}
	if ( angle < 0 ) {
		angle += D_2_PI;
	} else if ( angle > D_2_PI ) {
		angle -= D_2_PI;
	}
	ballApplyMovement(wball,angle,speed);
}

void snookerTackleRandom(PSnooker snooker, TFloat speed) {
	ballApplyMovement(snookerGetCueBall(snooker),D_2_PI * (float)rand() / (float)RAND_MAX,speed);
}

int snookerSetupOfficialBallColors(PSnooker snooker) {
	if ( snooker->balls != D_BALLS ) {
		return 0;
	}
	ballSetColor(snooker->ball[D_CUEBALL],1.0,1.0,1.0);
	ballSetColor(snooker->ball[1],1.0,0.0,0.0);
	ballSetColor(snooker->ball[2],1.0,0.0,0.0);
	ballSetColor(snooker->ball[3],1.0,0.0,0.0);
	ballSetColor(snooker->ball[4],1.0,0.0,0.0);
	ballSetColor(snooker->ball[5],1.0,0.0,0.0);
	ballSetColor(snooker->ball[6],1.0,0.0,0.0);
	ballSetColor(snooker->ball[7],1.0,0.0,0.0);
	ballSetColor(snooker->ball[8],1.0,0.0,0.0);
	ballSetColor(snooker->ball[9],1.0,0.0,0.0);
	ballSetColor(snooker->ball[10],1.0,0.0,0.0);
	ballSetColor(snooker->ball[11],1.0,0.0,0.0);
	ballSetColor(snooker->ball[12],1.0,0.0,0.0);
	ballSetColor(snooker->ball[13],1.0,0.0,0.0);
	ballSetColor(snooker->ball[14],1.0,0.0,0.0);
	ballSetColor(snooker->ball[15],1.0,0.0,0.0);
	ballSetColor(snooker->ball[16],0.0,0.0,0.0);
	ballSetColor(snooker->ball[17],1.0,1.0,0.0);
	ballSetColor(snooker->ball[18],0.0,1.0,0.0);
	ballSetColor(snooker->ball[19],0.0,0.0,1.0);
	ballSetColor(snooker->ball[20],1.0,0.0,1.0);
	ballSetColor(snooker->ball[21],0.4,0.24,0.19);
	return 1;
}

void snookerSetCameraHeight(PSnooker snooker, TFloat height) {
	if ( height < D_TABLE_FLOOR_HEIGHT + 0.1 ) {
		height = D_TABLE_FLOOR_HEIGHT + 0.1;
	}
	snooker->camera.height = height;
}

void snookerSetCameraDistance(PSnooker snooker, TFloat distance) {
	snooker->camera.distance = distance;
}

void snookerSetCameraAngle(PSnooker snooker, TFloat angle) {
	snooker->camera.angle = angle;
}

void snookerAddCameraAngle(PSnooker snooker, TFloat angle) {
	snooker->camera.angle += angle;
}

void snookerSetCameraMode(PSnooker snooker, int mode) {
	snooker->camera.mode = mode;
}

void snookerSetCameraPosition(PSnooker snooker, TFloat x, TFloat y, TFloat z) {
	snooker->camera.x = x;
	snooker->camera.y = y;
	snooker->camera.z = z;
}
