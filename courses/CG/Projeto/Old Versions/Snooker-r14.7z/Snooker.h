#ifndef SNOOKER_H_INCLUDED
#define SNOOKER_H_INCLUDED

#include	<stdlib.h>
#include	<stdio.h>
#include	<math.h>
#include	"SnookerDefs.h"
#include	"Table.h"
#include	"Ball.h"

typedef struct {
	int		mode;
	// centered camera mode only.
	TFloat	angle;											// angle between the camera direction and the x axis.
	TFloat	height;											// height relative to the table of the camera.
	TFloat	distance;										// distance of the center of the rotation center.
	// static camera mode only.
	TFloat	x, y, z;										// the static position of the camera.
} TCamera, *PCamera;

typedef struct {
	TUVertex	position2D, dimension2D;					// 2D view port positioning and dimensioning (minimap).
	TUVertex	position3D, dimension3D;					// 3D view port positioning and dimensioning (3d scenario).
	PTable		table;
	unsigned	balls;
	PBall		*ball;
	int			paused;
	TCamera		camera;
} TSnooker, *PSnooker;

PSnooker	snookerCreate();
void		snookerDestroy(PSnooker *snkr);
void		snookerSetupTable(PSnooker snooker, TFloat totalWidth, TFloat totalHeight, TFloat width, TFloat height,
			TFloat pocketSize, TFloat atrCoef);
int			snookerSetupOfficialBallColors(PSnooker snooker);
void		snookerSetTable2DBounds(PSnooker snooker, TUVertex p, TUVertex d);
void		snookerSetTable3DBounds(PSnooker snooker, TUVertex p, TUVertex d);
void		snookerSetupBalls(PSnooker snooker, unsigned balls, TFloat radius, TFloat mass);
void		snookerSetupCueBall(PSnooker snooker, TFloat radius, TFloat mass);
PBall		snookerGetCueBall(PSnooker snooker);
unsigned	snookerGetBalls(PSnooker snooker);
PBall		snookerGetBall(PSnooker snooker, unsigned ball);
void		snookerThink(PSnooker snooker, TFloat timeEllapsed);
void		snookerPaint2D(PSnooker snooker);
void		snookerPaint3D(PSnooker snooker);
int			snookerIsPaused(PSnooker snooker);
void		snookerPause(PSnooker snooker, int pause);
void		snookerClearBallFlag(PSnooker snooker, int ball, unsigned flag);
void		snookerSetBallFlag(PSnooker snooker, int ball, unsigned flag);
int			snookerMovementInProgress(PSnooker snooker);
int			snookerGameEnded(PSnooker snooker);
void		snookerTackleRandomBall(PSnooker snooker, TFloat speed);
void		snookerTackleRandom(PSnooker snooker, TFloat speed);
void		snookerTackleClosestBall(PSnooker snooker, TFloat speed);
void		snookerTackleFartestBall(PSnooker snooker, TFloat speed);
void		snookerSetCameraHeight(PSnooker snooker, TFloat height);
void		snookerSetCameraDistance(PSnooker snooker, TFloat distance);
void		snookerSetCameraAngle(PSnooker snooker, TFloat angle);
void		snookerAddCameraAngle(PSnooker snooker, TFloat angle);
void		snookerSetCameraMode(PSnooker snooker, int mode);
void		snookerSetCameraPosition(PSnooker snooker, TFloat x, TFloat y, TFloat z);

#endif // SNOOKER_H_INCLUDED
