#include	<stdlib.h>
#include	<stdio.h>
#include	<unistd.h>
#include	<time.h>
#include	<GL/gl.h>
#include	<GL/glu.h>
#include	<GL/glut.h>
#include	"Snooker.h"

#define	D_WINDOW_WIDTH				1000
#define	D_WINDOW_HEIGHT				486

#define D_LAYOUT_RIGHTBAR_WIDTH		300

#define	D_STATE_STOPPED				0
#define	D_STATE_PREPARING			1
#define	D_STATE_RUNNING				2
#define	D_STATE_ENDED				3

float		timeRatio = 1.0;
PSnooker	snooker;
unsigned	fps = 0, state = D_STATE_STOPPED;
float		nowTime = 0, lastTime = 0, timeElapsed = 0, timeFPS = 0;

int proportion(int X1, int Y1, int X2) {
	return Y1 * X2 / X1;
}

void resize(int width, int height) {
//	snookerSetTable2DBounds(snooker,uvertex(0,0),uvertex(width,height));
	snookerSetTable2DBounds(snooker,uvertex(width - D_LAYOUT_RIGHTBAR_WIDTH,height - D_LAYOUT_RIGHTBAR_WIDTH / (int)D_TABLE_ASPECT),uvertex(D_LAYOUT_RIGHTBAR_WIDTH,D_LAYOUT_RIGHTBAR_WIDTH / (int)D_TABLE_ASPECT));
	snookerSetTable3DBounds(snooker,uvertex(0,0),uvertex(width - D_LAYOUT_RIGHTBAR_WIDTH,height));
}

void display(void) {

	// fps computing.
	nowTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
	timeElapsed = nowTime - lastTime;
	lastTime = nowTime;
	timeFPS += timeElapsed;
	fps++;

	// game process.
	if ( state == D_STATE_RUNNING && !snookerIsPaused(snooker) ) {
		if ( timeFPS > 1.0 ) {
			timeFPS = 0;
			fps = 0;
		}
		snookerThink(snooker,timeElapsed / timeRatio);
		if ( !snookerMovementInProgress(snooker) ) {
			if ( snookerGameEnded(snooker) ) {
				state = D_STATE_ENDED;
				printf("> Game Over!\n");
			} else {
				state = D_STATE_STOPPED;
			}
		}
	}

	// rendering.
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	snookerPaint2D(snooker);
	snookerPaint3D(snooker);

	glutSwapBuffers();
}


void key(unsigned char key, int x, int y) {
	if ( key == ' ' ) {
		if ( snookerIsPaused(snooker) ) {
			snookerPause(snooker,0);
		} else {
			snookerPause(snooker,1);
		}
		lastTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
	} else if ( key == 'r' ) {
		timeRatio += 0.1;
	} else if ( key == 't' ) {
		if ( timeRatio > 0.1 ) {
			timeRatio -= 0.1;
		}
	} else if ( key == 'y' && state == D_STATE_STOPPED ) {
		snookerTackleRandomBall(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'u' && state == D_STATE_STOPPED ) {
		snookerTackleClosestBall(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'i' && state == D_STATE_STOPPED ) {
		snookerTackleFartestBall(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'o' && state == D_STATE_STOPPED ) {
		snookerTackleRandom(snooker,0.4);
		state = D_STATE_RUNNING;
	} else if ( key == 'p' ) {
		if ( ballGetFlag(snookerGetCueBall(snooker),BALL_DRAW_SPEED_VECTOR) ) {
			snookerClearBallFlag(snooker,-1,BALL_DRAW_SPEED_VECTOR);
		} else {
			snookerSetBallFlag(snooker,-1,BALL_DRAW_SPEED_VECTOR);
		}
	} else if ( key == 'd' ) {
		snookerAddCameraAngle(snooker,-M_PI / 360.0);
//		snookerAddCameraPosition(snooker,0.1,0.0,0.0);
	} else if ( key == 's' ) {
		snookerAddCameraPosition(snooker,0.0,-0.1,0.0);
	} else if ( key == 'w' ) {
		snookerAddCameraPosition(snooker,0.0,0.1,0.0);
	} else if ( key == 'a' ) {
		snookerAddCameraAngle(snooker,M_PI / 360.0);
//		snookerAddCameraPosition(snooker,-0.1,0.0,0.0);
	}
	glutPostRedisplay();
}

void idle(void) {
	if ( snookerIsPaused(snooker) ) {
		usleep(50000);
	} else if ( !snookerMovementInProgress(snooker) ) {
		usleep(10000);
		lastTime = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
	} else {
		glutPostRedisplay();
	}
}

int main(int argc, char *argv[]) {

	printf("> Keys:\n");
	printf("  r       reduz a velocidade do tempo.\n");
	printf("  t       aumenta a velocidade do tempo.\n");
	printf("  p       liga/desliga o desenho dos vetores velocidade.\n");
	printf("  espaco  pause.\n");
	printf("  o       tacada aleatoria\n");
	printf("  i       tacada na bola mais distante da bola branca.\n");
	printf("  u       tacada na bola mais proxima da bola branca.\n");
	printf("  y       tacada em uma bola aleatoria.\n\n");

	#ifndef DISABLE_RANDSEED
		srand(time(0));
	#endif

    glutInit(&argc, argv);
    glutInitWindowSize(D_WINDOW_WIDTH,D_WINDOW_HEIGHT);
    glutInitWindowPosition(0,0);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);

    glutCreateWindow("Snooker");

    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutKeyboardFunc(key);
    glutIdleFunc(idle);

    glClearColor(0,0,0,0);

	// prepare the game.
	snooker = snookerCreate();
	snookerSetupTable(snooker,D_TABLE_WIDTH + D_TABLE_BORDER,D_TABLE_HEIGHT + D_TABLE_BORDER,D_TABLE_WIDTH,D_TABLE_HEIGHT,D_TABLE_POCKET_DIAMETER,0.00017);
	snookerSetupBalls(snooker,D_BALLS,D_BALL_RADIUS,D_BALL_MASS);
	snookerSetupCueBall(snooker,D_CUEBALL_RADIUS,D_CUEBALL_MASS);
	snookerSetupOfficialBallColors(snooker);
	snookerPause(snooker,0);

	// enable AA.
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_POLYGON_SMOOTH);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);

	// prepare clear color.
	glClearColor(0.0,0.0,0.0,0.0);

	snookerSetCameraMode(snooker,D_CAMERA_MODE_CENTERED);

    glutMainLoop();

    return EXIT_SUCCESS;
}
