#include <stdlib.h>
#include <math.h>
#include "Table.h"

PTable tableCreate(TFloat totalWidth, TFloat totalHeight) {
	PTable table = malloc(sizeof(TTable));
	table->totalWidth = totalWidth;
	table->totalHeight = totalHeight;
	table->pocket = (PVertex)malloc(sizeof(TVertex) * TABLE_POCKETS);
	return table;
}

void tableDestroy(PTable *table) {
	if ( table && *table ) {
		free((*table)->pocket);
		free(*table);
		*table = 0;
	}
}

void tableSetup(PTable t, TFloat width, TFloat height, TFloat pocketSize, TFloat atrCoef) {
	t->width = width;
	t->height = height;
	t->pocketSize = pocketSize;
	t->atrCoef = atrCoef;
	t->pockets = 0x22222;

	TFloat	slice = pocketSize / D_SQRT_2;
	TFloat	recoil = slice;
//	TFloat	border = tableGetBorder(t);
	TFloat	border = 0.0;

	t->bound[0] = lineCreate(vertex(border + D_TABLE_POCKET_MOUTH * slice,border),vertex(border,border - recoil));
	t->bound[1] = lineCreate(vertex(border,border - recoil),vertex(border - recoil,border));
	t->bound[2] = lineCreate(vertex(border - recoil,border),vertex(border,border + D_TABLE_POCKET_MOUTH * slice));

	t->bound[3] = lineCreate(vertex(border,border + D_TABLE_POCKET_MOUTH * slice),vertex(border,t->height + border - D_TABLE_POCKET_MOUTH * slice));

	t->bound[4] = lineCreate(vertex(border,t->height + border - D_TABLE_POCKET_MOUTH * slice),vertex(border - recoil,t->height + border + slice - recoil));
	t->bound[5] = lineCreate(vertex(border - recoil,t->height + border + slice - recoil),vertex(border + slice - recoil,t->height + border + recoil));
	t->bound[6] = lineCreate(vertex(border + slice - recoil,t->height + border + recoil),vertex(border + D_TABLE_POCKET_MOUTH * slice,t->height + border));

	t->bound[7] = lineCreate(vertex(border + D_TABLE_POCKET_MOUTH * slice,t->height + border),vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,t->height + border));

	t->bound[8] = lineCreate(vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,t->height + border),vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * slice,t->height + border + recoil));
	t->bound[9] = lineCreate(vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * slice,t->height + border + recoil),vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * slice,t->height + border + recoil));
	t->bound[10] = lineCreate(vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * slice,t->height + border + recoil),vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,t->height + border));

	t->bound[11] = lineCreate(vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,t->height + border),vertex(t->width + border - D_TABLE_POCKET_MOUTH * slice,t->height + border));

	t->bound[12] = lineCreate(vertex(t->width + border - D_TABLE_POCKET_MOUTH * slice,t->height + border), vertex(t->width + border - slice + recoil,t->height + border + recoil));
	t->bound[13] = lineCreate(vertex(t->width + border - slice + recoil,t->height + border + recoil), vertex(t->width + border + recoil,t->height + border + slice - recoil));
	t->bound[14] = lineCreate(vertex(t->width + border + recoil,t->height + border + slice - recoil), vertex(t->width + border,t->height + border - D_TABLE_POCKET_MOUTH * slice));

	t->bound[15] = lineCreate(vertex(t->width + border,t->height + border - D_TABLE_POCKET_MOUTH * slice), vertex(t->width + border,border + D_TABLE_POCKET_MOUTH * slice));

	t->bound[16] = lineCreate(vertex(t->width + border,border + D_TABLE_POCKET_MOUTH * slice),vertex(t->width + border + recoil,border + slice - recoil));
	t->bound[17] = lineCreate(vertex(t->width + border + recoil,border + slice - recoil),vertex(t->width + border - slice + recoil,border - recoil));
	t->bound[18] = lineCreate(vertex(t->width + border - slice + recoil,border - recoil),vertex(t->width + border - D_TABLE_POCKET_MOUTH * slice,border));

	t->bound[19] = lineCreate(vertex(t->width + border - D_TABLE_POCKET_MOUTH * slice,border),vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,border));

	t->bound[20] = lineCreate(vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,border),vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * slice,border - recoil));
	t->bound[21] = lineCreate(vertex(t->width / 2.0 + border + D_SQRT_2 * 0.5 * slice,border - recoil),vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * slice,border - recoil));
	t->bound[22] = lineCreate(vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * slice,border - recoil),vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,border));

	t->bound[23] = lineCreate(vertex(t->width / 2.0 + border - D_SQRT_2 * 0.5 * D_TABLE_POCKET_MOUTH * slice,border),vertex(border + D_TABLE_POCKET_MOUTH * slice,border));

	border = tableGetBorder(t);
	t->pocket[0].x = border - D_COS_PI_4 * slice;				t->pocket[0].y = border - D_SIN_PI_4 * slice;
	t->pocket[1].x = border - D_COS_PI_4 * slice;				t->pocket[1].y = t->height + border + D_SIN_PI_4 * slice;
	t->pocket[2].x = t->totalWidth / 2.0;						t->pocket[2].y = t->height + border + t->pocketSize / 2.0;
	t->pocket[3].x = t->width + border + D_COS_PI_4 * slice;	t->pocket[3].y = t->height + border + D_SIN_PI_4 * slice;
	t->pocket[4].x = t->width + border + D_COS_PI_4 * slice;	t->pocket[4].y = border - D_SIN_PI_4 * slice;
	t->pocket[5].x = t->totalWidth / 2.0;						t->pocket[5].y = border - t->pocketSize / 2.0;

	#ifdef DEBUG
		glBegin(GL_LINES);
		glColor3f(1,0,0);
			int	i = 0;
			for ( i = 0; i < TABLE_BOUNDS; i++ ) {
				glVertex2f(t->bound[i]->p1.x + border,t->bound[i]->p1.y + border);
				glVertex2f(t->bound[i]->p2.x + border,t->bound[i]->p2.y + border);
			}
		glEnd();
	#endif
}

void tablePaint3D(PTable t, TFloat ballRadius) {

	TFloat	border = tableGetBorder(t);
	TFloat	pocketRadius = t->pocketSize / 2.0;

	// draw the table foots.
	glColor3f(0.34,0.18,0.13);
	glPushMatrix();
		glScalef(2 * border,2 * border,D_TABLE_FLOOR_HEIGHT - border);
		glTranslatef(0.5,0.5,0.5);
		glutSolidCube(1.0);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(t->totalWidth - 2 * border,0.0,0.0);
		glScalef(2 * border,2 * border,D_TABLE_FLOOR_HEIGHT - border);
		glTranslatef(0.5,0.5,0.5);
		glutSolidCube(1.0);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(t->totalWidth - 2 * border,t->totalHeight - 2 * border,0.0);
		glScalef(2 * border,2 * border,D_TABLE_FLOOR_HEIGHT - border);
		glTranslatef(0.5,0.5,0.5);
		glutSolidCube(1.0);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(0.0,t->totalHeight - 2 * border,0.0);
		glScalef(2 * border,2 * border,D_TABLE_FLOOR_HEIGHT - border);
		glTranslatef(0.5,0.5,0.5);
		glutSolidCube(1.0);
	glPopMatrix();

	// draw the table base.
	glPushMatrix();
		glTranslatef(border / 10.0,border / 10.0,D_TABLE_FLOOR_HEIGHT - border - D_TABLE_FLOOR_HEIGHT / 4.0);
		glScalef(t->totalWidth - border / 5.0,t->totalHeight - border / 5.0,D_TABLE_FLOOR_HEIGHT / 4.0);
		glTranslatef(0.5,0.5,0.5);
		glutSolidCube(1.0);
	glPopMatrix();

	// draw the table border.
	TFloat	borderHeight = D_TABLE_FLOOR_HEIGHT + 1.5 * ballRadius;
	glBegin(GL_QUADS);
		glVertex3f(0,0,D_TABLE_FLOOR_HEIGHT - border);
		glVertex3f(0,0,borderHeight);
		glVertex3f(t->totalWidth,0,borderHeight);
		glVertex3f(t->totalWidth,0,D_TABLE_FLOOR_HEIGHT - border);

		glVertex3f(t->totalWidth,0,D_TABLE_FLOOR_HEIGHT - border);
		glVertex3f(t->totalWidth,0,borderHeight);
		glVertex3f(t->totalWidth,t->totalHeight,borderHeight);
		glVertex3f(t->totalWidth,t->totalHeight,D_TABLE_FLOOR_HEIGHT - border);

		glVertex3f(t->totalWidth,t->totalHeight,D_TABLE_FLOOR_HEIGHT - border);
		glVertex3f(0,t->totalHeight,D_TABLE_FLOOR_HEIGHT - border);
		glVertex3f(0,t->totalHeight,borderHeight);
		glVertex3f(t->totalWidth,t->totalHeight,borderHeight);

		glVertex3f(0,t->totalHeight,D_TABLE_FLOOR_HEIGHT - border);
		glVertex3f(0,0,D_TABLE_FLOOR_HEIGHT - border);
		glVertex3f(0,0,borderHeight);
		glVertex3f(0,t->totalHeight,borderHeight);
	glEnd();

	// pocket cilinders.
	glColor3f(0.0,0.0,0.4);
	glPushMatrix();
		glTranslatef(t->pocket[0].x,t->pocket[0].y,D_TABLE_FLOOR_HEIGHT + 0.75 * ballRadius);
		glScalef(2 * pocketRadius,2 * pocketRadius,1.5 * ballRadius);
		glRotatef(135,0.0,0.0,1.0);
		drawCilinderSection(M_PI,20);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(t->pocket[1].x,t->pocket[1].y,D_TABLE_FLOOR_HEIGHT + 0.75 * ballRadius);
		glScalef(2 * pocketRadius,2 * pocketRadius,1.5 * ballRadius);
		glRotatef(45,0.0,0.0,1.0);
		drawCilinderSection(M_PI,20);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(t->pocket[2].x,t->pocket[2].y,D_TABLE_FLOOR_HEIGHT + 0.75 * ballRadius);
		glScalef(2 * pocketRadius,2 * pocketRadius,1.5 * ballRadius);
		drawCilinderSection(M_PI,20);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(t->pocket[3].x,t->pocket[3].y,D_TABLE_FLOOR_HEIGHT + 0.75 * ballRadius);
		glScalef(2 * pocketRadius,2 * pocketRadius,1.5 * ballRadius);
		glRotatef(315,0.0,0.0,1.0);
		drawCilinderSection(M_PI,20);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(t->pocket[4].x,t->pocket[4].y,D_TABLE_FLOOR_HEIGHT + 0.75 * ballRadius);
		glScalef(2 * pocketRadius,2 * pocketRadius,1.5 * ballRadius);
		glRotatef(225,0.0,0.0,1.0);
		drawCilinderSection(M_PI,20);
	glPopMatrix();

	glPushMatrix();
		glTranslatef(t->pocket[5].x,t->pocket[5].y,D_TABLE_FLOOR_HEIGHT + 0.75 * ballRadius);
		glScalef(2 * pocketRadius,2 * pocketRadius,1.5 * ballRadius);
		glRotatef(180,0.0,0.0,1.0);
		drawCilinderSection(M_PI,20);
	glPopMatrix();

	// table internal border.
	glBegin(GL_QUADS);
		glVertex3f(border + t->bound[0]->p1.x,border + t->bound[0]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[0]->p1.x,border + t->bound[0]->p1.y,borderHeight);
		glVertex3f(border + t->bound[1]->p1.x,border + t->bound[1]->p1.y,borderHeight);
		glVertex3f(border + t->bound[1]->p1.x,border + t->bound[1]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[2]->p1.x,border + t->bound[2]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[2]->p1.x,border + t->bound[2]->p1.y,borderHeight);
		glVertex3f(border + t->bound[3]->p1.x,border + t->bound[3]->p1.y,borderHeight);
		glVertex3f(border + t->bound[3]->p1.x,border + t->bound[3]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[3]->p1.x,border + t->bound[3]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[3]->p1.x,border + t->bound[3]->p1.y,borderHeight);
		glVertex3f(border + t->bound[4]->p1.x,border + t->bound[4]->p1.y,borderHeight);
		glVertex3f(border + t->bound[4]->p1.x,border + t->bound[4]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[4]->p1.x,border + t->bound[4]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[4]->p1.x,border + t->bound[4]->p1.y,borderHeight);
		glVertex3f(border + t->bound[5]->p1.x,border + t->bound[5]->p1.y,borderHeight);
		glVertex3f(border + t->bound[5]->p1.x,border + t->bound[5]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[6]->p1.x,border + t->bound[6]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[6]->p1.x,border + t->bound[6]->p1.y,borderHeight);
		glVertex3f(border + t->bound[7]->p1.x,border + t->bound[7]->p1.y,borderHeight);
		glVertex3f(border + t->bound[7]->p1.x,border + t->bound[7]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[7]->p1.x,border + t->bound[7]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[7]->p1.x,border + t->bound[7]->p1.y,borderHeight);
		glVertex3f(border + t->bound[8]->p1.x,border + t->bound[8]->p1.y,borderHeight);
		glVertex3f(border + t->bound[8]->p1.x,border + t->bound[8]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[8]->p1.x,border + t->bound[8]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[8]->p1.x,border + t->bound[8]->p1.y,borderHeight);
		glVertex3f(border + t->bound[9]->p1.x,border + t->bound[9]->p1.y,borderHeight);
		glVertex3f(border + t->bound[9]->p1.x,border + t->bound[9]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[10]->p1.x,border + t->bound[10]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[10]->p1.x,border + t->bound[10]->p1.y,borderHeight);
		glVertex3f(border + t->bound[11]->p1.x,border + t->bound[11]->p1.y,borderHeight);
		glVertex3f(border + t->bound[11]->p1.x,border + t->bound[11]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[11]->p1.x,border + t->bound[11]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[11]->p1.x,border + t->bound[11]->p1.y,borderHeight);
		glVertex3f(border + t->bound[12]->p1.x,border + t->bound[12]->p1.y,borderHeight);
		glVertex3f(border + t->bound[12]->p1.x,border + t->bound[12]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[12]->p1.x,border + t->bound[12]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[12]->p1.x,border + t->bound[12]->p1.y,borderHeight);
		glVertex3f(border + t->bound[13]->p1.x,border + t->bound[13]->p1.y,borderHeight);
		glVertex3f(border + t->bound[13]->p1.x,border + t->bound[13]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[14]->p1.x,border + t->bound[14]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[14]->p1.x,border + t->bound[14]->p1.y,borderHeight);
		glVertex3f(border + t->bound[15]->p1.x,border + t->bound[15]->p1.y,borderHeight);
		glVertex3f(border + t->bound[15]->p1.x,border + t->bound[15]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[15]->p1.x,border + t->bound[15]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[15]->p1.x,border + t->bound[15]->p1.y,borderHeight);
		glVertex3f(border + t->bound[16]->p1.x,border + t->bound[16]->p1.y,borderHeight);
		glVertex3f(border + t->bound[16]->p1.x,border + t->bound[16]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[16]->p1.x,border + t->bound[16]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[16]->p1.x,border + t->bound[16]->p1.y,borderHeight);
		glVertex3f(border + t->bound[17]->p1.x,border + t->bound[17]->p1.y,borderHeight);
		glVertex3f(border + t->bound[17]->p1.x,border + t->bound[17]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[18]->p1.x,border + t->bound[18]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[18]->p1.x,border + t->bound[18]->p1.y,borderHeight);
		glVertex3f(border + t->bound[19]->p1.x,border + t->bound[19]->p1.y,borderHeight);
		glVertex3f(border + t->bound[19]->p1.x,border + t->bound[19]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[19]->p1.x,border + t->bound[19]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[19]->p1.x,border + t->bound[19]->p1.y,borderHeight);
		glVertex3f(border + t->bound[20]->p1.x,border + t->bound[20]->p1.y,borderHeight);
		glVertex3f(border + t->bound[20]->p1.x,border + t->bound[20]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[20]->p1.x,border + t->bound[20]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[20]->p1.x,border + t->bound[20]->p1.y,borderHeight);
		glVertex3f(border + t->bound[21]->p1.x,border + t->bound[21]->p1.y,borderHeight);
		glVertex3f(border + t->bound[21]->p1.x,border + t->bound[21]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[22]->p1.x,border + t->bound[22]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[22]->p1.x,border + t->bound[22]->p1.y,borderHeight);
		glVertex3f(border + t->bound[23]->p1.x,border + t->bound[23]->p1.y,borderHeight);
		glVertex3f(border + t->bound[23]->p1.x,border + t->bound[23]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[23]->p1.x,border + t->bound[23]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[23]->p1.x,border + t->bound[23]->p1.y,borderHeight);
		glVertex3f(border + t->bound[0]->p1.x,border + t->bound[0]->p1.y,borderHeight);
		glVertex3f(border + t->bound[0]->p1.x,border + t->bound[0]->p1.y,D_TABLE_FLOOR_HEIGHT);
	glEnd();

	// draw the border.
	glColor3f(1.0,1.0,0.0);
	glBegin(GL_POLYGON);
		glVertex3f(border + t->bound[2]->p1.x,	border + t->bound[2]->p1.y,		borderHeight);
		glVertex3f(0.0,							border + t->bound[2]->p1.y,		borderHeight);
		glVertex3f(0.0,							border + t->bound[5]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[5]->p1.x,	border + t->bound[5]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[4]->p1.x,	border + t->bound[4]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[3]->p1.x,	border + t->bound[3]->p1.y,		borderHeight);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex3f(border + t->bound[6]->p1.x,	border + t->bound[6]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[6]->p1.x,	t->totalHeight,					borderHeight);
		glVertex3f(border + t->bound[9]->p1.x,	t->totalHeight,					borderHeight);
		glVertex3f(border + t->bound[9]->p1.x,	border + t->bound[9]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[8]->p1.x,	border + t->bound[8]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[7]->p1.x,	border + t->bound[7]->p1.y,		borderHeight);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex3f(border + t->bound[10]->p1.x,	border + t->bound[10]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[10]->p1.x,	t->totalHeight,					borderHeight);
		glVertex3f(border + t->bound[13]->p1.x,	t->totalHeight,					borderHeight);
		glVertex3f(border + t->bound[13]->p1.x,	border + t->bound[13]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[12]->p1.x,	border + t->bound[12]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[11]->p1.x,	border + t->bound[11]->p1.y,	borderHeight);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex3f(border + t->bound[14]->p1.x,	border + t->bound[14]->p1.y,	borderHeight);
		glVertex3f(t->totalWidth,				border + t->bound[14]->p1.y,	borderHeight);
		glVertex3f(t->totalWidth,				border + t->bound[17]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[17]->p1.x,	border + t->bound[17]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[16]->p1.x,	border + t->bound[16]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[15]->p1.x,	border + t->bound[15]->p1.y,	borderHeight);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex3f(border + t->bound[18]->p1.x,	border + t->bound[18]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[18]->p1.x,	0.0,							borderHeight);
		glVertex3f(border + t->bound[21]->p1.x,	0.0,							borderHeight);
		glVertex3f(border + t->bound[21]->p1.x,	border + t->bound[21]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[20]->p1.x,	border + t->bound[20]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[19]->p1.x,	border + t->bound[19]->p1.y,	borderHeight);
	glEnd();

	glBegin(GL_POLYGON);
		glVertex3f(border + t->bound[22]->p1.x,	border + t->bound[22]->p1.y,	borderHeight);
		glVertex3f(border + t->bound[22]->p1.x,	0.0,							borderHeight);
		glVertex3f(border + t->bound[1]->p1.x,	0.0,							borderHeight);
		glVertex3f(border + t->bound[1]->p1.x,	border + t->bound[1]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[0]->p1.x,	border + t->bound[0]->p1.y,		borderHeight);
		glVertex3f(border + t->bound[23]->p1.x,	border + t->bound[23]->p1.y,	borderHeight);
	glEnd();

	// draw the table green area.
	glColor3f(0.0,0.4,0.0);
	glBegin(GL_QUADS);
		glVertex3f(border,border,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border,t->height + border,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(t->width + border,t->height + border,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(t->width + border,border,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[0]->p1.x,border + t->bound[0]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[1]->p1.x,border + t->bound[1]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[2]->p1.x,border + t->bound[2]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[3]->p1.x,border + t->bound[3]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[4]->p1.x,border + t->bound[4]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[5]->p1.x,border + t->bound[5]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[6]->p1.x,border + t->bound[6]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[7]->p1.x,border + t->bound[7]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[8]->p1.x,border + t->bound[8]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[9]->p1.x,border + t->bound[9]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[10]->p1.x,border + t->bound[10]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[11]->p1.x,border + t->bound[11]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[12]->p1.x,border + t->bound[12]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[13]->p1.x,border + t->bound[13]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[14]->p1.x,border + t->bound[14]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[15]->p1.x,border + t->bound[15]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[16]->p1.x,border + t->bound[16]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[17]->p1.x,border + t->bound[17]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[18]->p1.x,border + t->bound[18]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[19]->p1.x,border + t->bound[19]->p1.y,D_TABLE_FLOOR_HEIGHT);

		glVertex3f(border + t->bound[20]->p1.x,border + t->bound[20]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[21]->p1.x,border + t->bound[21]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[22]->p1.x,border + t->bound[22]->p1.y,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + t->bound[23]->p1.x,border + t->bound[23]->p1.y,D_TABLE_FLOOR_HEIGHT);
	glEnd();

	// draw the pockets.
//	TFloat	slice = t->pocketSize / (D_SQRT_2 * 2);

	glColor3f(0,0,0);
	int	i;
	for ( i = 0; i < TABLE_POCKETS; i++ ) {
		printf("i=%d pocketRadius=%.3f x=%.3f y=%.3f\n",i,pocketRadius,t->pocket[i].x,t->pocket[i].y);
		drawCircle3Dxy(pocketRadius,t->pocket[i].x,t->pocket[i].y,D_TABLE_FLOOR_HEIGHT + 0.0001);
	}
//	drawCircle3Dxy(pocketRadius,border - D_COS_PI_4 * slice,border - D_SIN_PI_4 * slice,D_TABLE_FLOOR_HEIGHT);
//	drawCircle3Dxy(pocketRadius,border - D_COS_PI_4 * slice,t->height + border + D_SIN_PI_4 * slice,D_TABLE_FLOOR_HEIGHT);
//	drawCircle3Dxy(pocketRadius,t->width + border + D_COS_PI_4 * slice,t->height + border + D_SIN_PI_4 * slice,D_TABLE_FLOOR_HEIGHT);
//	drawCircle3Dxy(pocketRadius,t->width + border + D_COS_PI_4 * slice,border - D_SIN_PI_4 * slice,D_TABLE_FLOOR_HEIGHT);
//	drawCircle3Dxy(pocketRadius,t->totalWidth / 2.0,border - t->pocketSize / 2.0,D_TABLE_FLOOR_HEIGHT);
//	drawCircle3Dxy(pocketRadius,t->totalWidth / 2.0,t->height + border + t->pocketSize / 2.0,D_TABLE_FLOOR_HEIGHT);

	// draw the baulk area.
	TFloat	baulkX = D_TABLE_BAULKLINE_DISTANCE * t->width / D_TABLE_WIDTH;
	glColor3f(0.7,0.7,0.7);
	glBegin(GL_LINES);
		glVertex3f(border + baulkX,border,D_TABLE_FLOOR_HEIGHT);
		glVertex3f(border + baulkX,border + t->height,D_TABLE_FLOOR_HEIGHT);
	glEnd();

	// draw the D.
	TFloat	baulkR = D_TABLE_BAULK_RADIUS * t->width / D_TABLE_WIDTH;
	drawWiredCircleSection3Dxy(baulkR,border + baulkX,border + t->height / 2.0,D_PI_2,D_3_PI_2,0.1,D_TABLE_FLOOR_HEIGHT);

}

void tablePaint2D(PTable t) {

	TFloat	border = tableGetBorder(t);

	// draw the table border.
	glColor3f(0.34,0.18,0.13);
	glBegin(GL_QUADS);
		glVertex2f(0,0);
		glVertex2f(0,t->totalHeight);
		glVertex2f(t->totalWidth,t->totalHeight);
		glVertex2f(t->totalWidth,0);
	glEnd();

	// draw the table green area.
	glColor3f(0.0,0.4,0.0);
	glBegin(GL_QUADS);
		glVertex2f(border,border);
		glVertex2f(border,t->height + border);
		glVertex2f(t->width + border,t->height + border);
		glVertex2f(t->width + border,border);

		glVertex2f(border + t->bound[0]->p1.x,border + t->bound[0]->p1.y);
		glVertex2f(border + t->bound[1]->p1.x,border + t->bound[1]->p1.y);
		glVertex2f(border + t->bound[2]->p1.x,border + t->bound[2]->p1.y);
		glVertex2f(border + t->bound[3]->p1.x,border + t->bound[3]->p1.y);

		glVertex2f(border + t->bound[4]->p1.x,border + t->bound[4]->p1.y);
		glVertex2f(border + t->bound[5]->p1.x,border + t->bound[5]->p1.y);
		glVertex2f(border + t->bound[6]->p1.x,border + t->bound[6]->p1.y);
		glVertex2f(border + t->bound[7]->p1.x,border + t->bound[7]->p1.y);

		glVertex2f(border + t->bound[8]->p1.x,border + t->bound[8]->p1.y);
		glVertex2f(border + t->bound[9]->p1.x,border + t->bound[9]->p1.y);
		glVertex2f(border + t->bound[10]->p1.x,border + t->bound[10]->p1.y);
		glVertex2f(border + t->bound[11]->p1.x,border + t->bound[11]->p1.y);

		glVertex2f(border + t->bound[12]->p1.x,border + t->bound[12]->p1.y);
		glVertex2f(border + t->bound[13]->p1.x,border + t->bound[13]->p1.y);
		glVertex2f(border + t->bound[14]->p1.x,border + t->bound[14]->p1.y);
		glVertex2f(border + t->bound[15]->p1.x,border + t->bound[15]->p1.y);

		glVertex2f(border + t->bound[16]->p1.x,border + t->bound[16]->p1.y);
		glVertex2f(border + t->bound[17]->p1.x,border + t->bound[17]->p1.y);
		glVertex2f(border + t->bound[18]->p1.x,border + t->bound[18]->p1.y);
		glVertex2f(border + t->bound[19]->p1.x,border + t->bound[19]->p1.y);

		glVertex2f(border + t->bound[20]->p1.x,border + t->bound[20]->p1.y);
		glVertex2f(border + t->bound[21]->p1.x,border + t->bound[21]->p1.y);
		glVertex2f(border + t->bound[22]->p1.x,border + t->bound[22]->p1.y);
		glVertex2f(border + t->bound[23]->p1.x,border + t->bound[23]->p1.y);
	glEnd();

	// draw the pockets.
	TFloat	slice = t->pocketSize / (D_SQRT_2 * 2);

	glColor3f(0,0,0);
	drawCircle2D(t->pocketSize / 2.0,border - D_COS_PI_4 * slice,border - D_SIN_PI_4 * slice);
	drawCircle2D(t->pocketSize / 2.0,border - D_COS_PI_4 * slice,t->height + border + D_SIN_PI_4 * slice);
	drawCircle2D(t->pocketSize / 2.0,t->width + border + D_COS_PI_4 * slice,t->height + border + D_SIN_PI_4 * slice);
	drawCircle2D(t->pocketSize / 2.0,t->width + border + D_COS_PI_4 * slice,border - D_SIN_PI_4 * slice);
	drawCircle2D(t->pocketSize / 2.0,t->totalWidth / 2.0,border - t->pocketSize / 2.0);
	drawCircle2D(t->pocketSize / 2.0,t->totalWidth / 2.0,t->height + border + t->pocketSize / 2.0);

	// draw the baulk area.
	TFloat	baulkX = D_TABLE_BAULKLINE_DISTANCE * t->width / D_TABLE_WIDTH;
	glColor3f(0.7,0.7,0.7);
	glBegin(GL_LINES);
		glVertex2f(border + baulkX,border);
		glVertex2f(border + baulkX,border + t->height);
	glEnd();

	// draw the D.
	TFloat	baulkR = D_TABLE_BAULK_RADIUS * t->width / D_TABLE_WIDTH;
	drawWiredCircleSection2D(baulkR,border + baulkX,border + t->height / 2.0,D_PI_2,D_3_PI_2,0.1);

	#ifdef	DEBUG
		border = tableGetBorder(t);
		glLoadIdentity();
		glBegin(GL_LINES);
			glColor3f(1,0,0);
			int	i = 0;
			for ( i = 0; i < TABLE_BOUNDS; i++ ) {
				glVertex2f(t->bound[i]->p1.x + border,t->bound[i]->p1.y + border);
				glVertex2f(t->bound[i]->p2.x + border,t->bound[i]->p2.y + border);
			}
		glEnd();
	#endif
}

int tableCollided(PTable table, PBall ball) {
	unsigned	hit = 0, i;
	for ( i = 0; i < TABLE_BOUNDS; i++ ) {
		if ( lineBallCollided(table->bound[i],ball) ) {
			hit |= (unsigned)1 << i;
		}
	}
	return hit;
}

int tableInPocket(PTable table, PBall ball, int hit) {
	return hit & table->pockets;
}

TFloat tableCollisionTime(PTable table, PBall ball, int hit) {
	TFloat	time = 0.0;
	int		i;
	for ( i = 0; i < TABLE_BOUNDS; i++ ) {
		if ( hit & 1 ) {
			TFloat	t = 0.0;
			if ( table->bound[i]->p1.x == table->bound[i]->p2.x ) {
				// vertical.
				TFloat	d = ball->radius - distancePointToLineSegment(vertex(ball->x,ball->y),table->bound[i]);
				t = fabs(d / ballSpeedX(ball));
			} else if ( table->bound[i]->p1.y == table->bound[i]->p2.y ) {
				// horizontal.
				TFloat	d = ball->radius - distancePointToLineSegment(vertex(ball->x,ball->y),table->bound[i]);
				t = fabs(d / ballSpeedY(ball));
			} else {
				// rotate.
				TFloat	d, a = -atan(angularCoef(table->bound[i]->p1,table->bound[i]->p2));
				TFloat	mr[2][2];
				TLine	l;
				TVertex	c;
				mr[0][0] = cos(a);
				mr[0][1] = -sin(a);
				mr[1][0] = -mr[0][1];
				mr[1][1] = mr[0][0];
				c.x = mr[0][0] * ball->x + mr[0][1] * ball->y;
				c.y = mr[1][0] * ball->x + mr[1][1] * ball->y;
				l.p1.x = mr[0][0] * table->bound[i]->p1.x + mr[0][1] * table->bound[i]->p1.y;
				l.p1.y = mr[1][0] * table->bound[i]->p1.x + mr[1][1] * table->bound[i]->p1.y;
				l.p2.x = mr[0][0] * table->bound[i]->p2.x + mr[0][1] * table->bound[i]->p2.y;
				l.p2.y = mr[1][0] * table->bound[i]->p2.x + mr[1][1] * table->bound[i]->p2.y;
				// distance.
				d = ball->radius - distancePointToLineSegment(c,&l);
				// time.
				t = fabs(d / (sin(ball->angle - a) * ballSpeed(ball)));
			}
			if ( t > time ) {
				time = t;
			}
		}
		hit = hit >> 1;
	}
	return time;
}

int tableCollision(PTable table, PBall ball, int hit) {
	if ( !hit ) {
		return 0;
	}
	int	bound = 0, bound2 = 0, i = 0, count = 0;
	for ( i = 0; i < TABLE_BOUNDS; i++ ) {
		if ( hit & 1 ) {
			if ( count >= 1 ) {
				bound2 = i;
			} else {
				bound = i;
			}
			count++;
		}
		hit = hit >> 1;
	}
	TFloat	ra;
	if ( count == 1 ) {
		if ( table->bound[bound]->p1.x == table->bound[bound]->p2.x ) {
			// vertical.
			if ( ball->x >= table->bound[bound]->p1.x ) {
				if ( ball->angle <= D_PI ) {
					ra = -D_PI_2;
				} else {
					ra = -D_3_PI_2;
				}
			} else {
				if ( ball->angle <= D_PI ) {
					ra = -D_PI_2;
				} else {
					ra = -D_3_PI_2;
				}
			}
			ball->angle += ra;
			ball->angle *= -1.0;
			ball->angle -= ra;
		} else if ( table->bound[bound]->p1.y == table->bound[bound]->p2.y ) {
			// horizontal.
			if ( ball->y >= table->bound[bound]->p1.y ) {
				if ( ball->angle < D_3_PI_2 ) {
					ra = -D_2_PI;
				} else {
					ra = -D_PI;
				}
			} else {
				if ( ball->angle < D_PI_2 ) {
					ra = 0.0;
				} else {
					ra = -D_PI;
				}
			}
			ball->angle += ra;
			ball->angle *= -1.0;
			ball->angle -= ra;
		} else {
			// inclined.
			TFloat	sa = -atan(angularCoef(table->bound[bound]->p1,table->bound[bound]->p2));
			TFloat	mr[2][2];
			TLine	l;
			TVertex	c;
			mr[0][0] = cos(sa);
			mr[0][1] = -sin(sa);
			mr[1][0] = -mr[0][1];
			mr[1][1] = mr[0][0];
//			c.x = mr[0][0] * ball->x + mr[0][1] * ball->y;
			c.y = mr[1][0] * ball->x + mr[1][1] * ball->y;
			l.p1.x = mr[0][0] * table->bound[bound]->p1.x + mr[0][1] * table->bound[bound]->p1.y;
			l.p1.y = mr[1][0] * table->bound[bound]->p1.x + mr[1][1] * table->bound[bound]->p1.y;
			l.p2.x = mr[0][0] * table->bound[bound]->p2.x + mr[0][1] * table->bound[bound]->p2.y;
			l.p2.y = mr[1][0] * table->bound[bound]->p2.x + mr[1][1] * table->bound[bound]->p2.y;
			// apply the rotation.
			ball->angle -= sa;
			if ( c.y >= l.p1.y ) {
				if ( ball->angle < D_3_PI_2 ) {
					ra = -D_3_PI_2;
				} else {
					ra = -D_2_PI;
				}
			} else {
				if ( ball->angle < D_PI_2 ) {
					ra = 0.0;
				} else {
					ra = -D_PI;
				}
			}
			ball->angle -= ra;
			ball->angle *= -1.0;
			ball->angle += ra - sa;
		}
	} else {
		// corner.
		TVertex	corner;
		if ( sameVertex(table->bound[bound]->p1,table->bound[bound2]->p1) ) {
			corner = table->bound[bound]->p1;
		} else if ( sameVertex(table->bound[bound]->p1,table->bound[bound2]->p2) ) {
			corner = table->bound[bound]->p1;
		} else {
			corner = table->bound[bound]->p2;
		}
		TFloat	sa = atan(-1.0 / angularCoef(corner,vertex(ball->x,ball->y)));
		TFloat	mr[2][2];
		TLine	l;
		TVertex	c;
		mr[0][0] = cos(sa);
		mr[0][1] = -sin(sa);
		mr[1][0] = -mr[0][1];
		mr[1][1] = mr[0][0];
		c.x = mr[0][0] * ball->x + mr[0][1] * ball->y;
		c.y = mr[1][0] * ball->x + mr[1][1] * ball->y;
		l.p1.x = mr[0][0] * corner.x + mr[0][1] * corner.y;
		l.p1.y = mr[1][0] * corner.x + mr[1][1] * corner.y;
		l.p2.x = mr[0][0] * corner.x + mr[0][1] * corner.y;
		l.p2.y = mr[1][0] * corner.x + mr[1][1] * corner.y;
		ball->angle -= sa;
		if ( c.y >= l.p1.y ) {
			if ( ball->angle < D_3_PI_2 ) {
				ra = -D_3_PI_2;
			} else {
				ra = -D_2_PI;
			}
		} else {
			if ( ball->angle < D_PI_2 ) {
				ra = 0.0;
			} else {
				ra = -D_PI;
			}
		}
		ball->angle -= ra;
		ball->angle *= -1.0;
		ball->angle += ra - sa;
	}
	ball->angle /= D_2_PI;
	ball->angle = (ball->angle - trunc(ball->angle)) * D_2_PI;
	ball->speed *= D_TABLE_HIT_SPEED_RATIO;
	return hit;
}

TFloat tableGetBorder(PTable table) {
	return (table->totalWidth - table->width) / 2.0;
}

TFloat tableGetAtrCoef(PTable table) {
	return table->atrCoef;
}

TFloat tableGetTotalWidth(PTable table) {
	return table->totalWidth;
}

TFloat tableGetTotalHeight(PTable table) {
	return table->totalHeight;
}
