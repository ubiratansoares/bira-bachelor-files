//*****************************************************
//
// Exemplo3D.cpp 
// Um programa OpenGL simples que abre uma janela GLUT 
// e desenha um cubo para exemplificar a visualiza��o
// de objetos 3D utilizando a proje��o perspectiva.
//
// Marcelo Cohen e Isabel H. Manssour
// Este c�digo acompanha o livro 
// "OpenGL - Uma Abordagem Pr�tica e Objetiva"
// 
//*****************************************************

#include <stdlib.h>
#include <GL/glut.h>

// Vari�veis para controles de navega��o
GLfloat fAspect;


void desenhaCubo() {

	glBegin ( GL_QUADS );
               
		// Front Face
        glColor3f(1.0f, 0.0f, 0.0f);
		glVertex3f(-1.0f, -1.0f,  1.0f);
        glColor3f(0.0f, 1.0f, 0.0f);
		glVertex3f( 1.0f, -1.0f,  1.0f);
        glColor3f(0.0f, 0.0f, 1.0f);
		glVertex3f( 1.0f,  1.0f,  1.0f);
        glColor3f(0.0f, 0.0f, 0.0f);
		glVertex3f(-1.0f,  1.0f,  1.0f);
              
		// Back Face
        glColor3f(0.0f, 0.0f, 0.0f);
		glVertex3f(-1.0f, -1.0f, -1.0f);
        glVertex3f(-1.0f,  1.0f, -1.0f);
		glVertex3f( 1.0f,  1.0f, -1.0f);
		glVertex3f( 1.0f, -1.0f, -1.0f);

		// Top Face
		glVertex3f(-1.0f,  1.0f, -1.0f);
		glVertex3f(-1.0f,  1.0f,  1.0f);
		glVertex3f( 1.0f,  1.0f,  1.0f);
		glVertex3f( 1.0f,  1.0f, -1.0f);

		// Bottom Face
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f( 1.0f, -1.0f, -1.0f);
		glVertex3f( 1.0f, -1.0f,  1.0f);
		glVertex3f(-1.0f, -1.0f,  1.0f);

		// Right face
		glVertex3f( 1.0f, -1.0f, -1.0f);
		glVertex3f( 1.0f,  1.0f, -1.0f);
		glVertex3f( 1.0f,  1.0f,  1.0f);
		glVertex3f( 1.0f, -1.0f,  1.0f);

		// Left Face
		glVertex3f(-1.0f, -1.0f, -1.0f);
		glVertex3f(-1.0f, -1.0f,  1.0f);
		glVertex3f(-1.0f,  1.0f,  1.0f);
		glVertex3f(-1.0f,  1.0f, -1.0f);

	glEnd();
}

// Fun��o callback de redesenho da janela de visualiza��o
void Desenha(void)
{
	// Limpa a janela de visualiza��o com a cor  
	// de fundo definida previamente
	glClear(GL_COLOR_BUFFER_BIT);

    // Limpa o buffer de profundidade
    glClear(GL_DEPTH_BUFFER_BIT);

    // Fun��o para fazer o desenho de um cubo 
    desenhaCubo();
        
	// Troca os buffers de desenho
	glutSwapBuffers();
}

// Fun��o usada para especificar o volume de visualiza��o
void EspecificaParametrosVisualizacao(void)
{
	// Especifica sistema de coordenadas de proje��o
	glMatrixMode(GL_PROJECTION);
	// Inicializa sistema de coordenadas de proje��o
	glLoadIdentity();

	// Especifica a proje��o perspectiva(angulo,aspecto,zMin,zMax)
	gluPerspective(60, fAspect, 0.5, 500);

	// Especifica sistema de coordenadas do modelo
	glMatrixMode(GL_MODELVIEW);
	// Inicializa sistema de coordenadas do modelo
	glLoadIdentity();

	// Especifica posi��o do observador e do alvo
	gluLookAt(3, 3, 3, 0,0,0, 0,1,0);
}

// Fun��o callback chamada quando o tamanho da janela � alterado 
void AlteraTamanhoJanela(GLsizei w, GLsizei h)
{
	// Para previnir uma divis�o por zero
	if ( h == 0 ) h = 1;

	// Especifica as dimens�es da viewport
	glViewport(0, 0, w, h);
 
	// Calcula a corre��o de aspecto
	fAspect = (GLfloat)w/(GLfloat)h;

	EspecificaParametrosVisualizacao();
}

// Fun��o respons�vel por inicializar par�metros e vari�veis
void Inicializa (void)
{   
    glEnable(GL_DEPTH_TEST);

	// Define a cor de fundo da janela de visualiza��o como branca
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glLineWidth(2.0);
	fAspect = 1.0f;
}




// Programa Principal 
int main(int argc, char *argv[])
{

    glutInit(&argc, argv);	

    // Define do modo de opera��o da GLUT
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH); 

	// Especifica a posi��o inicial da janela GLUT
	glutInitWindowPosition(5,5); 

	// Especifica o tamanho inicial em pixels da janela GLUT
	glutInitWindowSize(450,450); 
 
	// Cria a janela passando como argumento o t�tulo da mesma
	glutCreateWindow("Desenho de um cubo");

	// Registra a fun��o callback de redesenho da janela de visualiza��o
	glutDisplayFunc(Desenha);

	// Registra a fun��o callback de redimensionamento da janela de visualiza��o
	glutReshapeFunc(AlteraTamanhoJanela);

	// Chama a fun��o respons�vel por fazer as inicializa��es 
	Inicializa();

 	// Inicia o processamento e aguarda intera��es do usu�rio
	glutMainLoop();

	return 0;
}
