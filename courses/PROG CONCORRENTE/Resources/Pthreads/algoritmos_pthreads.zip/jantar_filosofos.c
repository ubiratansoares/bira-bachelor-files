#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
 
#define N 5
#define LEFT (i+N-1)%N
#define RIGHT (i+1)%N
#define THINKING 0
#define HUNGRY 1
#define EATING 2
 
#define TRUE 1
 
typedef sem_t semaphore;
int state[N];
semaphore mutex;
semaphore s[N];
 
void think(int i) {
	printf("Filosofo %d esta pensando\n", i);
}
 
void eat(int i) {
	printf("Filosofo %d esta comendo\n", i);
}
 
void test(int i) {
	if (state[i] == HUNGRY && state[LEFT] != EATING && state[RIGHT]    != EATING) {
		state[i] = EATING;
		sem_post(&s[i]);    
	}
}
 
void take_forks(int i) {
	sem_wait(&mutex);
	state[i] = HUNGRY;
	test(i);
	sem_post(&mutex);
	sem_wait(&s[i]);
}
 
void put_forks(int i) {
	sem_wait(&mutex);
	state[i] = THINKING;
	test(LEFT);
	test(RIGHT);
	sem_post(&mutex);
}
 
void* philosopher(void *i) {
	int f = *(int*) i;
	while(TRUE) {
		think(f);
		take_forks(f);
		eat(f);
		put_forks(f);    
	}
}
 
int main() {
	pthread_t thread[N];
	sem_init(&mutex, 0, 1);
	int i;
	for(i=0; i<N; i++) {
		sem_init(&s[i], 0, 0);
		pthread_create(&thread[i], NULL, philosopher, &i);
	}
	void* out;
	for(i=0; i<N; i++)
		pthread_join(thread[i], &out);
	return 0;
}
