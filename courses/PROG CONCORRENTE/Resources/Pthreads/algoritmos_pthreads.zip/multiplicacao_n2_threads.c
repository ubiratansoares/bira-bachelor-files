#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

int A[3][3];
int B[3][3];
int C[3][3];
int n = 3;

typedef struct {
	int linha;
	int coluna;
} thread_arg, *ptr_thread_arg;


pthread_t threads[3][3];

void *thread_func(void *arg) {
	ptr_thread_arg targ = (ptr_thread_arg)arg;
	int j;
	
		for(j=0; j< n; j++){
			C[targ->linha][targ->coluna] += A[targ->linha][j]*B[j][targ->coluna];
		}
}


int main(){
	thread_arg arguments[3][3];
	int i, j;
	
	//inicializando matrizes
	for(i=0; i<3; i++){
		for(j=0;j<3; j++){
			A[i][j] = 2;
			B[i][j] = 3;
			C[i][j] = 0;
		}
	}
	
	//cria as threads e atribui para cada uma a linha e a coluna para realizar a multiplicacao
	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			arguments[i][j].linha = i;
			arguments[i][j].coluna = j;
			pthread_create(&threads[i][j], NULL, thread_func, (void*) &arguments[i][j]);
		}
	}
	
	//sincroniza as threads	
	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			pthread_join(threads[i][j], NULL);
		}
	};
	
	//imprime o resultado
	for(i=0; i<3; i++){
		for(j=0;j<3; j++){
			printf("%d ", C[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
