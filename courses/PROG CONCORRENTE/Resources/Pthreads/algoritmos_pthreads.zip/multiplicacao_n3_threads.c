#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>

//variaveis globais
int A[3][3];
int B[3][3];
int C[3][3];
int n = 3;
pthread_mutex_t mutex_acesso;


typedef struct {
	int indice_c;
	int linha;
	int coluna;
} thread_arg, *ptr_thread_arg;


pthread_t threads[3][3][3];

void *thread_func(void *arg) {
	ptr_thread_arg targ = (ptr_thread_arg)arg;
	int j;
	pthread_mutex_lock(&mutex_acesso);
	C[targ->indice_c][targ->linha] += A[targ->linha][targ->coluna]*B[targ->coluna][targ->linha];
	pthread_mutex_unlock(&mutex_acesso);
}


int main(){
	thread_arg arguments[3][3][3];
	int i, j, k;
	
	//inicializando matrizes
	for(i=0; i<3; i++){
		for(j=0;j<3; j++){
			A[i][j] = 2;
			B[i][j] = 3;
			C[i][j] = 0;
		}
	}
	
	//cria as threads e atribui para cada uma um par de elementos da matriz A e B para realizar a multiplicacao
	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			for(k=0; k<3; k++){
				arguments[i][j][k].indice_c = i;
				arguments[i][j][k].linha = j;
				arguments[i][j][k].coluna = k;
				pthread_create(&threads[i][j][k], NULL, thread_func, (void*) &arguments[i][j][k]);
			}
		}
	}
	
	//sincroniza as threads	
	for(i=0; i<3; i++){
		for(j=0; j<3; j++){
			for(k=0; k<3; k++){
				pthread_join(threads[i][j][k], NULL);
			}
		}
	};
	
	//imprime o resultado
	for(i=0; i<3; i++){
		for(j=0;j<3; j++){
			printf("%d ", C[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
