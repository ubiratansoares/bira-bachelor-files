#include <stdio.h>
#include <pthread.h>
#include <math.h>
#define N 9999999
#define MAX_THREADS 20

pthread_t t[MAX_THREADS];
pthread_mutex_t mutex[N+1];
//int n = 0;
int vetor[N+1];

void *crivo(void* a) {
    int i = 1;
    int num = 0;
    int aux;

    while ( i <= sqrt(N) ) {
        aux = i;
        pthread_mutex_lock( &mutex[i] );
        while ( ( vetor[i] <= 0 ) && ( i <= sqrt(N) ) ) {
            pthread_mutex_unlock( &mutex[i] );
            i++;
            if ( i <= sqrt(N) )
                pthread_mutex_lock( &mutex[i] );
        }
        if ( i <= sqrt(N) ) {
            num = vetor[i];
            vetor[i] *= -1;
            pthread_mutex_unlock( &mutex[i] );
            for ( i += num; i <= N; i += num ) {
                pthread_mutex_lock( &mutex[i] );
                vetor[i] = 0;
                pthread_mutex_unlock( &mutex[i] );
            }
            i = num;
        }
    }

    pthread_exit(NULL);
    return 0;
}

int main() {
    int i = 0;

    vetor[0] = 0;
    mutex[0] = PTHREAD_MUTEX_INITIALIZER;
    vetor[1] = 0;
    mutex[1] = PTHREAD_MUTEX_INITIALIZER;
    for ( i = 2; i <= N; i++ ) {
        vetor[i] = i;
        mutex[i] = PTHREAD_MUTEX_INITIALIZER;
    }

    for ( i = 0; i < MAX_THREADS; i++ )
        if ( pthread_create(&(t[i]), NULL, crivo, NULL) != 0 ) {
            printf("Error.\n");
        }

    for ( i = 0; i < MAX_THREADS; i++ )
        if ( pthread_join(t[i], NULL) != 0 )
            printf("error\n");

    for ( i = 2; i <= N; i++ )
        if ( vetor[i] != 0 )
            printf("%d\n", abs(vetor[i]));

getchar();
    return 0;
}
