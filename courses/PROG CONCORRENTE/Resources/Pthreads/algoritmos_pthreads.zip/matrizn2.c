#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NUM_THREADS 4
#define N 5

float a[N][N], b[N][N], c[N][N];

void *hello(void* arg) {
    void** args = (void**) arg;
    int i = args[0];
    int j = args[1];
    int k;

    c[i][j] = 0.0f;
    /*printf("%ld: %d %d\n", pthread_self(), i, j);*/
    for ( k = 0; k < N; k++ ) {
        c[i][j] += a[i][k]*b[k][j];
    }
    /*printf("%ld: c = %f\n", pthread_self(), *c);

    printf("%d %d: %ld\n", i, j, pthread_self());*/
    return 0;
}

int main() {
    pthread_t id[N*N];
    void* status = 0;
    int i = 0, j = 0, k = 0;
    void** args[N][N];

    srand(time(NULL));
    for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            a[i][j] = rand()%11;
            b[i][j] = rand()%11;
        }
    }

    /* Algoritmo da Multiplicacao */
    /*for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            c[i][j] = 0.0f;
            for ( k = 0; k < N; k++ ) {
                c[i][j] += a[i][k]*b[k][j];
            }
        }
    }*/

    /* Imprime matriz A */
    /*for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            printf("%f\t", a[i][j]);
        }
        printf("\n");
    }*/

    /* Imprime matriz B */
    /*for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            printf("%f\t", b[i][j]);
        }
        printf("\n");
    }*/

    for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            args[i][j] = calloc(2, sizeof(void*));
            args[i][j][0] = i;
            args[i][j][1] = j;
            /*refer�ncia pra pthread_t,estrutura de atributos p thread,refe^rencia p func a ser executada,argumentos
            a serem passados*/
            if ( pthread_create(&(id[i*N+j]), NULL, &hello, (void*)args[i][j]) != 0 )
                /*printf("Thread criada %ld!\n", id[i*N+j]);
            else*/
               printf("Erro %d %d\n", i, j);
        }
    }

    for ( i = 0; i < N; i++ )
        for ( j = 0; j < N; j++ ) {
            /* refer�ncia para thread e referencia para status de retorno*/
        if ( pthread_join(id[i*N+j], &status) != 0 )
            printf("Erro %d %d\n", i, j);
            /*printf("Thread terminada %ld! Status: %ld\n", id[i*N+j], (long)status);*/
        }

    /* Imprime C */
    /*for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            printf("%f\t", c[i][j]);
        }
        printf("\n");
    }*/

    for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            float d = 0.0f;
            for ( k = 0; k < N; k++ ) {
                d += a[i][k]*b[k][j];
            }
            if ( d != c[i][j] ) {
                printf("ERRO!\n");
                return 1;
            }
        }
    }

    return 0;
}
