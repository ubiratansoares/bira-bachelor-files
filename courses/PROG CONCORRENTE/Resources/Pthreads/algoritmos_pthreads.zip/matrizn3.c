#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define N 5

float a[N][N], b[N][N], c[N][N];
pthread_mutex_t mutex[N][N];

void *hello(void* arg) {
    void** args = (void**) arg;
    int i = args[0];
    int j = args[1];
    int k = args[2];

    pthread_mutex_lock( &mutex[i][j] );
    c[i][j] += a[i][k]*b[k][j];
    pthread_mutex_unlock( &mutex[i][j] );
    return 0;
}

int main() {
    pthread_t id[N*N*N];
    void* status = 0;
    int i = 0, j = 0, k = 0;
    void** args[N][N][N];

    srand(time(NULL));
    for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            a[i][j] = rand()%11;
            b[i][j] = rand()%11;
            mutex[i][j] = PTHREAD_MUTEX_INITIALIZER;
        }
    }

    for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            c[i][j] = 0;
            for ( k = 0; k < N; k++ ) {
                args[i][j][k] = calloc(3, sizeof(void*));
                args[i][j][k][0] = i;
                args[i][j][k][1] = j;
                args[i][j][k][2] = k;
                if ( pthread_create(&(id[i*N*N+j*N+k]), NULL, &hello, (void*)args[i][j][k]) != 0 )
                    printf("Erro %d %d\n", i, j);
            }
        }
    }

    for ( i = 0; i < N; i++ )
        for ( j = 0; j < N; j++ )
            for ( k = 0; k < N; k++ ) {
                if ( pthread_join(id[i*N*N+j*N+k], &status) != 0 )
                    printf("Erro %d %d\n", i, j);
                    /*printf("Thread terminada %ld! Status: %ld\n", id[i*N*N+j*N+k], (long)status);*/
            }

    /* Imprime C */
    /*for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            printf("%f\t", c[i][j]);
        }
        printf("\n");
    }*/

    for ( i = 0; i < N; i++ ) {
        for ( j = 0; j < N; j++ ) {
            float d = 0.0f;
            for ( k = 0; k < N; k++ ) {
                d += a[i][k]*b[k][j];
            }
            if ( d != c[i][j] ) {
                printf("ERRO!\n");
                return 1;
            }
        }
    }

    return 0;
}

