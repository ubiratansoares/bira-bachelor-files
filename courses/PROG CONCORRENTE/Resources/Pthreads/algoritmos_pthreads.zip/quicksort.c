#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define N 10

int vetor[N];

void quicksort(void* a) {
    pthread_t sub[2];
    void** args = (void**) a;
    int ini = (int) args[0];
    int fim = (int) args[1];
    int i = ini;
    int j = fim;
    int k = 0;
    int entrou = 0;

    int ini1, ini2, fim1, fim2;
    void *args2[2], *args1[2];
    int status1, status2;

    int pivo = vetor[(fim+ini)/2];

    do {
        while ( vetor[i] < pivo ) {
            i++;
            if ( i > fim )
                break;
        }
        while ( vetor[j] > pivo ) {
            j--;
            if ( j < 0 )
                break;
        }
        if ( ( i <= fim ) && ( j >= 0 ) )
            if ( vetor[i] > vetor[j] ) {
                int aux = vetor[i];
                vetor[i] = vetor[j];
                vetor[j] = aux;
                i++;
                j--;
            }

        printf("Pivo: %d\n", pivo);
        for ( k = 0; k < N; k++ )
            printf("%d ", vetor[k]);

        getchar();
    } while ( i < j );

    ini1 = ini;
    ini2 = i;
    fim1 = j;
    fim2 = fim;

    args1[0] = ini1;
    args1[1] = fim1;
    args2[0] = ini2;
    args2[1] = fim2;

    printf("%d-%d %d-%d\n", ini, j, i, fim);
    getchar();

    if ( fim1 > ini )
        if ( pthread_create(&(sub[0]), NULL, &quicksort, args1) != 0 ) {
            printf("Erro ao criar, %d-%d.\n", ini1, fim1);
        }

    if ( ini2 < fim )
        if ( pthread_create(&(sub[1]), NULL, &quicksort, args2) != 0 ) {
            printf("Erro ao criar, %d-%d\n", ini2, fim2);
        }

    if ( fim1 > ini )
        if ( pthread_join(sub[0], &status1) != 0 ) {
            printf("Erro ao joinar, %d\n", i);
        }

    if ( ini2 < fim )
        if ( pthread_join(sub[1], &status2) != 0 ) {
            printf("Erro ao joinar, %d\n", i);
        }

    return 0;
    /*for ( ; j >= 0; j-- ) {
        printf("%d ", vetor[j]);
    }
    printf("\n");
    for ( ; i < N; i++ ) {
        printf("%d ", vetor[i]);
    }
    printf("\n");*/
}

int main() {
    pthread_t t;
    int i, j, k, status;
    void* a[2];

    srand(time(NULL));
    for ( i = 0; i < N; i++ )
        vetor[i] = rand()%N;

    /*quicksort(); */
    i = 0;
    j = N-1;
    a[0] = i;
    a[1] = j;

    for ( k = 0; k < 1000; k++ ) {
        if ( pthread_create(&t, NULL, &quicksort, a) != 0 )
            printf("Erro %d\n", i);

        if ( pthread_join(t, &status) != 0 )
            printf("Erro %d\n", i);


        for ( i = 1; i < N; i++ )
            if ( vetor[i-1] > vetor[i] ) {
                printf("ERRO!\n");
                return 1;
            }
        printf("OK %d\n", k);
    }
    /*for ( i = 0; i < NP; i++ ) {
        if ( pthread_create(&(p[i]), NULL, &producer, NULL) != 0 )
            printf("Erro %d\n", i);
    }

    for ( i = 0; i < NC; i++ ) {
        if ( pthread_create(&(c[i]), NULL, &consumer, NULL) != 0 )
            printf("Erro %d\n", i);
    }

    for ( i = 0; i < NP; i++ ) {
        if ( pthread_join(p[i], &status) != 0 )
            printf("Erro %d\n", i);
    }

    for ( i = 0; i < NC; i++ ) {
        if ( pthread_join(c[i], &status) != 0 )
            printf("Erro %d\n", i);
    }*/

    return 0;

}
