#include <stdio.h>
#include <pthread.h>

//matrix size (square matrix only =P)
#define MATRIX_SIZE 3
//boolean to choose when to use threads or not
#define USE_THREADS 0

//struct used to warn thread function what point must be calculated
typedef struct {
	int x;
	int y;
} point;

//matrix definitions (c is the result matrix)
int a[MATRIX_SIZE][MATRIX_SIZE], b[MATRIX_SIZE][MATRIX_SIZE], c[MATRIX_SIZE][MATRIX_SIZE];

//thread function (par is the point to be calculated by this thread)
void *thread(void *par) {
	point p;
	int i;
	p = *((point *)par);
	//matrix point calculation
	for (i = 0; i < MATRIX_SIZE; i++)
		c[p.x][p.y] += (a[p.x][i] * b[i][p.y]);
	pthread_exit(0);
}

int main(int argc, char *argv[]) {
	pthread_t threads[MATRIX_SIZE][MATRIX_SIZE];
	point p[MATRIX_SIZE][MATRIX_SIZE];
	int x, y, i;
	//matrix initialization
	for (x = 0; x < MATRIX_SIZE; x++)
		for (y = 0; y < MATRIX_SIZE; y++) {
			a[x][y] = x;
			b[x][y] = y;
			c[x][y] = 0;
			p[x][y].x = x;
			p[x][y].y = y;
		}
	//if we are using threads
	if (USE_THREADS) {
		for (x = 0; x < MATRIX_SIZE; x++)
			for (y = 0; y < MATRIX_SIZE; y++)
				pthread_create(&threads[x][y], NULL, thread, (void*)&p[x][y]);
		for (x = 0; x < MATRIX_SIZE; x++)
			for (y = 0; y < MATRIX_SIZE; y++)
				pthread_join(threads[x][y], NULL);
	} else
		//without threads
		for (x = 0; x < MATRIX_SIZE; x++)
			for (y = 0; y < MATRIX_SIZE; y++)
				for (i = 0; i < MATRIX_SIZE; i++)
					c[x][y] += (a[x][i] * b[i][y]);
	//display matrix a
	for (x = 0; x < MATRIX_SIZE; x++) {
		for (y = 0; y < MATRIX_SIZE; y++)
			printf("%d ", a[x][y]);
		printf("\n");
	}
	printf("\n");
	//display matrix b
	for (x = 0; x < MATRIX_SIZE; x++) {
		for (y = 0; y < MATRIX_SIZE; y++)
			printf("%d ", b[x][y]);
		printf("\n");
	}
	printf("\n");
	//display matrix c (result)
	for (x = 0; x < MATRIX_SIZE; x++) {
		for (y = 0; y < MATRIX_SIZE; y++)
			printf("%d ", c[x][y]);
		printf("\n");
	}
	return 0;
}
