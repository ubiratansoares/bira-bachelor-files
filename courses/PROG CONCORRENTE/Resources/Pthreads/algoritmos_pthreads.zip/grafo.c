#include <stdio.h>
#include <pthread.h>

/*
	  a
	 / \
	c   b
	|  /|\
	| d e f
	|/  / /
	g  / /
	 \/ /
	  \/
	   h
*/


pthread_t thread_b;
pthread_t thread_c;
pthread_t thread_d;
pthread_t thread_e;
pthread_t thread_f;
pthread_t thread_g;
pthread_t thread_h;

void *d(void *p);
void *e(void *p);
void *f(void *p);

void *b(void *p) {
	printf("b\n");
	pthread_create(&thread_d, NULL, d, NULL);
	pthread_create(&thread_e, NULL, e, NULL);
	pthread_create(&thread_f, NULL, f, NULL);
	pthread_exit(NULL);
}

void *d(void *p) {
	printf("d\n");
	pthread_exit(NULL);
}

void *e(void *p) {
	printf("e\n");
	pthread_exit(NULL);
}

void *f(void *p) {
	printf("f\n");
	pthread_exit(NULL);
}

int main (int argc, char *argv[]) {
	printf("a\n");
	pthread_create(&thread_b, NULL, b, NULL);
	printf("c\n");
	pthread_join(thread_b, NULL);
	pthread_join(thread_d, NULL);
	printf("g\n");
	pthread_join(thread_e, NULL);
	pthread_join(thread_f, NULL);
	printf("h\n");
	return 0;
}
