#include <stdio.h>
#include <pthread.h>

//size of our vector
#define VECTOR_SIZE 500
//boolean to choose when to use threads or not
#define USE_THREADS 1

//mutex for mutual exclusion control
pthread_mutex_t mutex;
//global vector
int m[VECTOR_SIZE];

//thread function (par is the number to be checked by this thread)
void *thread(void *par) {
	int item, i;
	item = ((int)par);
	//lock it up
	pthread_mutex_lock(&mutex);
	//if the number is still in the vector
	if (m[item] == item) {
		//update the vector
		for (i = (item * 2); i < VECTOR_SIZE; i += item)
			m[i] = 0;
	}
	//unlock it
	pthread_mutex_unlock(&mutex);
	//leave
	pthread_exit(NULL);
}

int main(int argc, char *argv[]) {
	pthread_t threads[VECTOR_SIZE];
	int i, j;
	//initialize 0 and 1 position (unused)
	m[0] = m[1] = 0;
	//initialize the rest of the vector
	for (i = 2; i < VECTOR_SIZE; i++)
		m[i] = i;
	//if we are using threads
	if (USE_THREADS) {
		//initializes mutex
		pthread_mutex_init(&mutex, NULL);
		//creates all threads
		for (i = 0; i < VECTOR_SIZE; i++)
			pthread_create(&threads[i], NULL, thread, (void *)(i+2));
		//sync all threads
		for (i = 0; i < VECTOR_SIZE; i++)
			pthread_join(threads[i], NULL);
		//destroys the mutex
		pthread_mutex_destroy(&mutex);
	} else {
		//without threads
		//checks every number starting from 2
		for (i = 2; i < VECTOR_SIZE; i++)
			if (m[i] == i)
				for (j = (i * 2); j < VECTOR_SIZE; j += i)
					m[j] = 0;
	}
	//prints every prime number
	for (i = 2; i < VECTOR_SIZE; i++)
		if (m[i] == i)
			printf("%d ", i);
	printf("\n");
	return 0;
}
