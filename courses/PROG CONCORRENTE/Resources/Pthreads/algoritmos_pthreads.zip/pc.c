#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define NC 20
#define NP 20
#define TAM 10 /*tamanho da pilha*/
#define PR 10 /* quanto cada produtor produz antes de morrer*/

int vetor[TAM];
int n = 0;
pthread_mutex_t mutex_vetor = PTHREAD_MUTEX_INITIALIZER;

int produz() {
    return rand()%101;
}

int poe_pilha(int aux) {
    if ( n < TAM - 1 ) {
        vetor[n] = aux;
        n++; /* topo da pilha incrementado*/
        return 1;
    }
    return 0;
}

int pega_pilha() {
    n--;
    return vetor[n];
}

void* producer(void* a) {
    int i = 0;
    int aux;
    for ( i = 0; i < PR; ) {
        aux = produz();
        pthread_mutex_lock( &mutex_vetor );
        if ( poe_pilha(aux) ) {
            i++;
            /*printf("Produziu %d, Produtor %ld\n", vetor[n-1], pthread_self());*/
        }
        pthread_mutex_unlock( &mutex_vetor );
    }
    printf("Acabei meu trabalho.\n");
    return 0;
}

void* consumer(void* a) {
    int i = 0;
    for ( i = 0; i < NP*PR/NC; ) {
        pthread_mutex_lock( &mutex_vetor );
        if ( n > 0 ) {
            i++;
            printf("Consumiu %d, Consumidor: %ld\n", pega_pilha(), pthread_self());
        }
        pthread_mutex_unlock( &mutex_vetor );
    }
    printf("Consumidor: %ld\n", pthread_self()); /* pthread_self() � o id da fun��o*/
    return 0;
}

int main() {
    pthread_t p[NP];
    pthread_t c[NC];
    int i, status;

    srand(time(NULL));

    for ( i = 0; i < NP; i++ ) {
        if ( pthread_create(&(p[i]), NULL, &producer, NULL) != 0 )
            printf("Erro %d\n", i);
    }
    for ( i = 0; i < NC; i++ ) {
        if ( pthread_create(&(c[i]), NULL, &consumer, NULL) != 0 )
            printf("Erro %d\n", i);
    }

    for ( i = 0; i < NP; i++ ) {
        if ( pthread_join(p[i], &status) != 0 )
            printf("Erro %d\n", i);
    }
    for ( i = 0; i < NC; i++ ) {
        /* enquanto n�o chegarem todas as threads n�o prossegue*/
        if ( pthread_join(c[i], &status) != 0 )
            printf("Erro %d\n", i);
    }
    return 0;

}
