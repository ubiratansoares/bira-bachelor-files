/*Solves a linear system using the Jacobi-Richardson iterative method*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <pthread.h>

#define DIM 3
//#define MAX_THREADS 2

float a[DIM][DIM];		/*System matrix*/
float x[DIM];				/*Variable vector*/
float b[DIM];				/*Constants vector*/
float y[DIM];				/*Stores the current candidate solution*/
float diff[DIM];			/*Stores the difference between current and previous solution*/

void *itera(void* arg) {
    int i = *((int*) arg);
    int j;

    y[i] = 0; /*Another initialization*/
    for (j = 0; j < DIM; j++) {
        if(i!=j) {
            y[i] += -a[i][j]*x[j]; /*Current guess*/
        }
    }
    y[i] += b[i]; /*Final current guess*/

    diff[i] = y[i] - x[i];

    x[i] = y[i];

    pthread_exit(NULL);
    return 0;
}


int main(int argc, char *argv[]) {


    pthread_t t[DIM];
    int ind[DIM];



	int i,j;						/*For loops*/

	float erro = 1000000.0;	/*Execution condition of the method*/
	float epsilon = 0;		/*Error value, defined by user*/

	float maxDiff = 0; 		/*Stores the maximum element of x - y vectorial difference*/
	float maxY = 0;			/*Stores the maximum element of y vector*/

	float aux = 0;				/*An auxiliar one ;) */


	printf("Jacobi-Richardson\n\n");

	/*Inicialization*/
	for (i = 0; i < DIM; i++) {
		for (j = 0; j < DIM; j++)
			a[i][j] = 0;
		b[i] = 0;
		x[i] = 0;
		y[i] = 0;
		diff[i] = 0;
	}

	/*Values of A matrix - informed by user*/
	printf("A matrix\n");
	for (i = 0; i < DIM; i++) {
		for (j = 0; j < DIM; j++) {
			printf("a%d%d = ",i+1,j+1);
			scanf("%f",&a[i][j]);
		}
	}

	/*Main diagonal verification*/
	for(i = 0; i < DIM; i++)
		if(a[i][i]==0) {
			printf("Jacobi-Richardson cannot be executed, because there is a zero on main diagonal.\n");
			exit(0);
		}

	/*Values of B vector - informed by user*/
	printf("\nb vector\n");
	for (j = 0; j < DIM; j++) {
		printf("b%d = ",j+1);
		scanf("%f",&b[j]);
	}

	/*Matrix A transformation, acording Jacobi-Richarson method*/
	for (i = 0; i < DIM; i++) {
		for (j = 0; j < DIM; j++) {
			if (i != j) a[i][j] = a[i][j]/a[i][i];
		}
		b[i] = b[i]/a[i][i];
		a[i][i] = 1;
	}

	/*The 1st guess*/
	printf("\nInitial values to x-vector\n");
	for (i = 0; i < DIM; i++) {
		printf("x%d = ",i+1);
		scanf("%f",&x[i]);
	}

	/*Precision - informed by user*/
	printf("Epsilon value = ");
	scanf("%f",&epsilon);

	/*Convergence verification*/
	for (i = 0; i < DIM; i++) {
		aux = 0;
		for (j = 0; j < DIM; j++) {
			if (j!=i) aux += fabs(a[i][j]);
		}
		if (aux >= fabs(a[i][i])) {
			 printf("Jacobi-Richardson can diverge, so it won't be executed.\n");
			 exit(0);
		}
	}

	/*Iteractions */
	while(erro >= epsilon) {
		for(i = 0; i < DIM; i++) {
		    ind[i] = i;
			pthread_create(&t[i], NULL, itera, (void*)&(ind[i]));
		}

		/*Difference between the current and previous guess*/
		for(i = 0; i < DIM; i++) {
			pthread_join(t[i], NULL);
		}

		/*Calculating the error*/
		maxDiff = fabs(diff[0]);
		maxY = fabs(y[0]);
		for(i = 1; i < DIM; i++) {
			if(maxDiff < fabs(diff[i])) maxDiff = fabs(diff[i]);
			if(maxY < fabs(y[i])) maxY = fabs(y[i]);
		}

		erro = maxDiff/maxY;

	} //while-end

	printf("\nSolution\n");
	for(i = 0; i < DIM; i++)
		printf("x%d = %f\n",i+1,y[i]);

	printf("\nError = %f\n",erro);

	printf("\n");
     system("PAUSE");
	return 0;
}

