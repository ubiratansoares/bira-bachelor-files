
//objeto auxiliar para definir retorno de métodos
public class descritor {
    int ender;
    boolean achou;
    
    descritor(){
        ender=-1;
        achou=false;
    }
}
