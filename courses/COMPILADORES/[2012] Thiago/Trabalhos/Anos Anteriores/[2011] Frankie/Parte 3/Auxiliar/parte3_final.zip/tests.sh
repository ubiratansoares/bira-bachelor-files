# Script para gerar os resultados do Analisador Lexico
# Autores : Ubiratan Soares, Humberto Yagi, Ulisses Soares
# Data : 30/03/2011


#!/bin/sh

dir="./Results"

if [[ ! -d $dir ]]; then mkdir $dir
fi	

echo "---------------------------------------------------------------------------"
echo "                ALL RESULT FILES WILL BE AT ./Results"
echo "---------------------------------------------------------------------------"

for i in $(find . -name "*.txt");
do
 	echo "--> Compiling file $i "

	java Parser  < "$i" > ./Results/`basename $i .txt`.txt
	
	echo "--> Generated `basename $i .txt`.txt"
			 
done
