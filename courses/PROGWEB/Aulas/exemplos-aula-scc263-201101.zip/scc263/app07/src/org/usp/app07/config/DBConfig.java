package org.usp.app07.config;

public interface DBConfig {
	// constantes
	// final -> constante
	public String driver = "org.gjt.mm.mysql.Driver";
	public String url = "jdbc:mysql://localhost:3306/app07db";
	public String username = "root";
	public String password = "";
}
