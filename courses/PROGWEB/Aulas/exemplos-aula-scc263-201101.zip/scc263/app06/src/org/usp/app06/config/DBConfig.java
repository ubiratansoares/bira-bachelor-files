package org.usp.app06.config;

public interface DBConfig {
	// constantes
	// final -> constante
	public String driver = "org.postgresql.Driver";
	public String url = "jdbc:postgresql://localhost:5432/app06db";
	public String username = "app06";
	public String password = "password";
}
