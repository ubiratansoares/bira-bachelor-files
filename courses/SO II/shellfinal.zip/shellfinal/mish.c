/*
 *  Arquivo : mish.c
 *  Contém a implementacao de programa principal de um SHELL Unix basico.
 *
 *	Esse arquivo faz parte de uma implementacao basica de um SHELL Unix, parte dos
 *	dos trabalhos de disciplina de Sistemas Operacionais II (SSC 0141)
 *
 *	Autores:
 *	Ubiratan Soares
 *	Ulisses Soares
 *  Vinicius Grippa
 *
 *	Data : 16/12/2009    
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <pwd.h>

#ifdef WITH_READLINE
 #include <readline/history.h>
 #include <readline/readline.h>
#endif

#include "parser.h"
#include "set_prompt.h"
#include "exec.h"
#include "signals.h"
#include "queue.h"


int sig_flag = 1;

int main (int argc, char **argv) {
	
	command_line_t command_line;	// Estrutura para armazenar os comandos no estilo argc e argv
	char *buffer;					// Linha obtida no prompt do usuario
	size_t buffer_size;				// Tamanho do buffer de entrada (usado com readline) 
	size_t read_bytes;				// Quantos bytes foram lidos na entrada (tb usado com readline)
	pid_t pid;						// Numero do processo corrente		
	int status;
	int redirect;					// Flag que indica se a linha de comando possui algum comando de redirecionamento de E/S
	struct passwd *user_info;		// Estrutura definida em pwd.h, contem informacoes do usuario

	FILE *fpout = NULL;
	FILE *fperr = NULL;
   	FILE *fpin = NULL;

	char *prompt = NULL;			// Prompt de comando do usuario
	queue qjobs;					// Fila para armazenar jobs
	job job;						// Variavel para armazenar um unico job

	// Inicializando fila de jobs
	
   	init_queue(&qjobs);
    

	// Obtendo informacoes do usuario
  
 	user_info = getpwnam(getlogin());
   	chdir(user_info->pw_dir);
   
	// Construindo o prompt inicial para o usuario

   	set_prompt(&prompt,user_info);
   //printf("\nOI  %s!\n",user_info->pw_name);

#ifdef WITH_SIGNAL


	// Associando handlers com seus respectivos sinais

   	signal(SIGINT, get_signal_SIGINT);
   	signal(SIGTSTP, get_signal_SIGTSTP);
   	signal(SIGCONT, get_signal_SIGCONT);

#endif
 
   	do{
	
		// LOOP PRINCIPAL DO SHELL


		// Leitura da linha de comando

		buffer = NULL;

#ifdef WITH_READLINE     

		buffer = readline(prompt);
		read_bytes = strlen(buffer);
#endif

#ifndef WITH_READLINE
		buffer_size = 0; 
       	fflush(stdout);   
       	printf("%s", prompt);
       	read_bytes = getline(&buffer, &buffer_size, stdin);
       	buffer[read_bytes-1] = 0;   /* Strip newline. */
#endif
		
		// Ajustando estrutura command_line via parser implementado

      	parse_command_line(buffer,&command_line) ;
      
      	if( command_line.argc > 0 ){
	
#ifdef WITH_READLINE

         		// Incluindo linha no historico de readline

				add_history(buffer);
#endif

				// Checando se o comando eh algum dos embutidos no shell, e executando se for o caso

         		if(strcmp(command_line.argv[0],"exit") == 0) // built-in exit : encerra o shell
            		exit(0);
         		
				else if( strcmp(command_line.argv[0],"cd") == 0 ){  // bult-in cd : muda o diretorio corrente
            	
						if( command_line.argc == 1 ) chdir(user_info->pw_dir);
						
							else if( strcmp(command_line.argv[1],"~") == 0 ) chdir(user_info->pw_dir);
 
           						else chdir(command_line.argv[1]);

	         			// Ajustando o prompt do usuario de acordo com o novo diretorio

						set_prompt(&prompt,user_info);

         			}//end built-in cd

         			else if( strcmp(command_line.argv[0],"fg") == 0 ){ // built-in fg : traz o processo para foreground
       
            				if( command_line.argc == 1 ) kill(dequeue(&qjobs),SIGCONT); 

            					else kill(atoi(command_line.argv[1]),SIGCONT);

         				}//end built-in fg

						else if( strcmp(command_line.argv[0],"bg") == 0 ){ // built-in bg : coloca o processo em background
         
            					if( command_line.argc == 1 ){
	
               							enqueue(command_line.argv[0],getpid(),&qjobs);
               							kill(getpid(),SIGTSTP);
            					}   
            					else {
               							enqueue("job",atoi(command_line.argv[1]),&qjobs);
               							kill(atoi(command_line.argv[1]),SIGTSTP);
            					} 

         					}//end built-in bg
   
      						else if( strcmp(command_line.argv[0],"jobs") == 0 ){ // built-in jobs : execucao de jobs
      
									job.pid = 1;
            						printf("JOBS:\n");

            						while(job.pid != -1){
	  
               							printf("%s\t%d\n",qjobs.q[qjobs.current].command,qjobs.q[qjobs.current].pid);
               							job = previous_item(&qjobs);
            						}
         						}
  
          
         						else {
										// O comando do usuario serah executado em um novo processo
	
           								pid = fork();
            							
										if (pid == -1) fatal();
            							
										else if(pid == 0){                                           
												
												// Processo filho	
												// Mudando E/S em caso de redirecionamento

               									redirect = redirect_io(redirect,fpout,fpin,fperr,command_line);
               
               									// Tratamento para processos em background

               									if (strcmp(command_line.argv[command_line.argc - 1],"&") == 0 ){
                  									command_line.argv[command_line.argc - 1] = NULL;
                  									raise(SIGTTOU);
               									} 
               
               									// Associando com handlers pre-definidos

               									signal(SIGINT,get_signal_SIGINT);
               									signal(SIGTSTP,get_signal_SIGTSTP);
               
               									// Executando o comando em conjunto com a variavel PATH, se ele existe

               									if (execvp(command_line.argv[0] , command_line.argv) == -1){  
                  									fatal(); 
                  									exit(0); // Sai do processo filho em caso de falha
               									}
               
               									// Testando se houve redirecionamento e recuperando I/O padrao

               									test_redirecting(&redirect,fpout,fpin,fperr);
                          
            								}//fim processo filho

            								else{
	 

               									// Normalmente, o processo pai aguarda o encerramento do filho
												// Se quisermos colocar um processo em background aqui, ignoramos waitpid

               									signal(SIGTSTP,get_signal_SIGTSTP);

               									if(strcmp(command_line.argv[command_line.argc - 1],"&") == 0 )

													printf("Background [%d]\t%s\n",getpid(),command_line.argv[0]);

               									else waitpid(pid, &status, WUNTRACED);

        									}//fim processo pai

         								}//fim de execucao em novo processo

      								}//fim da execucao do comando

      				free(buffer);    // Limpando buffer para proxima entrada


		}while(sig_flag);  // SHELL roda ateh o sinal ^C
   
   		free_queue(&qjobs);

   		free(prompt);

   		return EXIT_SUCCESS;

}//end main
