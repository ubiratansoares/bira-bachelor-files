/*
 *  Arquivo : parser.c
 *  Contém a implementacao da interface parser.h.
 *
 *	Esse arquivo faz parte de uma implementacao basica de um SHELL Unix, parte dos
 *	dos trabalhos de disciplina de Sistemas Operacionais II (SSC 0141)
 *
 *	Autores:
 *	Ubiratan Soares
 *	Ulisses Soares
 *  Vinicius Grippa
 *
 *	Data : 16/12/2009    
 */

#include <stdlib.h>
#include <argz.h>
#include <stdio.h>

#include "parser.h"


// Funcao : parse_command_line(buffer, command_line)
// Essa funcao aceita uma string, que eh o linha de comando lida no prompt do shell, e ajusta
// a estrutura de dados command_line, que contem os argumentos splitados e quantos eles sao.

void parse_command_line(char *buffer, command_line_t *command_line)
{

	char *argz;			// argz é uma cadeia de strings continua em memoria separada somente por '/0'
	size_t argz_length;	// Tamanho de argz

	// Utilizamos a fucao argz_create_sep para fazer a separacao dos argumentos lidos no prompt
	// do shell, passando como tokenizer o caracter em branco
      
   	if(argz_create_sep(buffer,' ',&argz,&argz_length)){

		// Mensagem em caso de erro ao splitar o buffer de entrada
	
		perror("ERROR : CANT CREAT ARGZ VECTOR.\n");
		exit (EXIT_FAILURE);
	}

	// O parser da linha de entrada ocorreu com sucesso. Ajustamos a estrutura command_line

	command_line->argc = argz_count(argz,argz_length);

	if(command_line->argc > 0){
	
	
		// Alocando os vetores de string em command_line
		
		command_line->argv = (char **)malloc((command_line->argc + 1)*sizeof(char *));
		
		
		// Copiando as strings para command_line
		 
		argz_extract(argz,argz_length,command_line->argv);

   }

   else command_line->argv = NULL;   
}

