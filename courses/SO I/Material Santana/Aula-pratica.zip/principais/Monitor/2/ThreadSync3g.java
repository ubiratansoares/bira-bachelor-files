/**
 * ThreadSync3g.java
 * This version uses Mailbox3g.java and Producers and Consumers
 * as before but with suitable variable renaming.
 * The Mailbox3g class has synchronized methods but does not
 * use wait and notify. The result is much inefficiency.
 */

public class ThreadSync3g {

	public static void main(String [] args) {
		Mailbox3g mailbox = new Mailbox3g();
		Consumer3g cons1 = new Consumer3g(mailbox);
		Producer3g prod1 = new Producer3g( mailbox, "Dave", "Hello, world.");
		Producer3g prod2 = new Producer3g(mailbox, "Bill", "Hot dog!");
		cons1.start();
		prod1.start();
		prod2.start();
	}
}

