#include <stdio.h>
#include <stdlib.h>

// definindo os códigos das operacoes

#define op_LW     35
#define op_TIPO_R 0
#define op_SW     43
#define op_ADDI   8     
#define op_ANDI   12    
#define op_BEQ    4
#define op_J      2
#define op_JAL    3     
#define op_JR     20   
#define op_JALR   21    
#define op_BNE    5    

//int UnidadeControle(int opcode);
//void ProxEstado(char ns0, char ns1, char ns2, char ns3);
//int GeraSinais(char s0, char s1, char s2, char s3);

static char estado = 0;

void ProxEstado(char ns0, char ns1, char ns2, char ns3) {
    estado = ns0;
    estado = estado + (ns1 << 1);
    estado = estado + (ns2 << 2);
    estado = estado + (ns3 << 3);
}

int GeraSinais(char s0, char s1, char s2, char s3) {
    int sinais = 0;

    char RegDst0 = 0, RegDst1 = 0, EscReg = 0, UALFonteA = 0, UALFonteB0 = 0, UALFonteB1 = 0, UALOp0 = 0, UALOp1 = 0, FontePC0 = 0,
        FontePC1 = 0, PCEscCond = 0, PCEsc = 0, IouD = 0, LerMem = 0, EscMem = 0, MemParaReg0 = 0, MemParaReg1 = 0, IREsc = 0, BNE = 0;


/*00*/RegDst0 =      (!s3 &  s2 &  s1 &  s0) || (!s3 &  s2 &  s1 &  s0) || ( s3 &  s2 &  s1 & !s0);
/*01*/RegDst1 =      ( s3 &  s2 & !s1 &  s0);
/*02*/EscReg =       (!s3 &  s2 & !s1 & !s0) || (!s3 &  s2 & !s1 & !s0) || (!s3 &  s2 &  s1 &  s0) || ( s3 & !s2 &  s1 &  s0);
/*03*/UALFonteA =    (!s3 & !s2 &  s1 & !s0) || (!s3 & !s2 &  s1 & !s0) || (!s3 &  s2 &  s1 & !s0) || ( s3 & !s2 & !s1 & !s0) || ( s3 &  s2 & !s1 & !s0) || ( s3 &  s2 &  s1 &  s0);
/*04*/UALFonteB0 =   (!s3 & !s2 & !s1 & !s0) || (!s3 & !s2 & !s1 &  s0);
/*05*/UALFonteB1 =   (!s3 & !s2 & !s1 &  s0) || (!s3 & !s2 &  s1 & !s0) || ( s3 &  s2 &  s1 &  s0);
/*06*/UALOp0 =       ( s3 & !s2 & !s1 & !s0) || ( s3 &  s2 & !s1 & !s0) || ( s3 &  s2 &  s1 &  s0);
/*07*/UALOp1 =       (!s3 &  s2 &  s1 & !s0) || ( s3 &  s2 &  s1 &  s0);
/*08*/FontePC0 =     ( s3 & !s2 & !s1 & !s0) || ( s3 & !s2 &  s1 & !s0) || ( s3 &  s2 & !s1 & !s0);
/*09*/FontePC1 =     ( s3 & !s2 & !s1 &  s0) || ( s3 & !s2 & !s1 &  s0) || ( s3 & !s2 &  s1 & !s0) || ( s3 &  s2 & !s1 &  s0);
/*10*/PCEscCond =    ( s3 & !s2 & !s1 & !s0) || ( s3 &  s2 & !s1 & !s0);
/*11*/PCEsc =        (!s3 & !s2 & !s1 & !s0) || ( s3 & !s2 & !s1 &  s0) || ( s3 & !s2 &  s1 & !s0) || ( s3 &  s2 & !s1 &  s0);
/*12*/IouD =         (!s3 & !s2 &  s1 &  s0) || (!s3 &  s2 & !s1 &  s0);
/*13*/LerMem =       (!s3 & !s2 & !s1 & !s0) || (!s3 & !s2 &  s1 &  s0);
/*14*/EscMem =       (!s3 &  s2 & !s1 &  s0);
/*15*/MemParaReg0 =  (!s3 &  s2 & !s1 & !s0);
/*16*/MemParaReg1 =  ( s3 &  s2 & !s1 &  s0) || ( s3 &  s2 &  s1 & !s0);
/*17*/IREsc =        (!s3 & !s2 & !s1 & !s0);
/*18*/BNE =          ( s3 &  s2 & !s1 & !s0);


    sinais = sinais + RegDst0;
    sinais = sinais + (RegDst1 << 1);
    sinais = sinais + (EscReg << 2);
    sinais = sinais + (UALFonteA << 3);
    sinais = sinais + (UALFonteB0 << 4);
    sinais = sinais + (UALFonteB1 << 5);
    sinais = sinais + (UALOp0 << 6);
    sinais = sinais + (UALOp1 << 7);
    sinais = sinais + (FontePC0 << 8);
    sinais = sinais + (FontePC1 << 9);
    sinais = sinais + (PCEscCond << 10);
    sinais = sinais + (PCEsc << 11);
    sinais = sinais + (IouD << 12);
    sinais = sinais + (LerMem << 13);
    sinais = sinais + (EscMem << 14);
    sinais = sinais + (MemParaReg0 << 15);
    sinais = sinais + (MemParaReg1 << 16);
    sinais = sinais + (IREsc << 17);
    sinais = sinais + (BNE << 18);

    return sinais;

}



int UnidadeControle(int opcode) {
    char s3 = 0, s2 = 0, s1 = 0, s0 = 0;     // armazenam os bits do estado atual da Máquina de Estados Finitos (MEF)
    char ns3 = 0, ns2 = 0, ns1 = 0, ns0 = 0; // armazenam os bits do próximo estado da Máquina de Estados Finitos (MEF)

    printf("esses: %d, %d", s3, s0);

    // isolando os bits de cada posicao da variavel "estado"
    s0 = (estado & 1);      // 0001
    s1 = (estado & 2) >> 1; // 0010
    s2 = (estado & 4) >> 2; // 0100
    s3 = (estado & 8) >> 3; // 1000

    // iniciando a Máquina de Estados Finitos (MEF)

    // a MEF está no estado 0
    if (!s3 & !s2 & !s1 & !s0) {
        // alterando os bits de "next state" para o estado 1
        ns0 = 1;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }

    // a MEF está no estado 1
    else
        if (!s3 & !s2 & !s1 & s0) {
            if (opcode == op_LW || opcode == op_SW || opcode == op_ADDI) {
                // alterando os bits de "next state" para o estado 2
                ns0 = 0;
                ns1 = 1;
                ns2 = 0;
                ns3 = 0;

            } else if (opcode == op_TIPO_R) {
                // alterando os bits de "next state" para o estado 6
                ns0 = 0;
                ns1 = 1;
                ns2 = 1;
                ns3 = 0;

            } else if (opcode == op_BEQ) {
                // alterando os bits de "next state" para o estado 8
                ns0 = 0;
                ns1 = 0;
                ns2 = 0;
                ns3 = 1;

            } else if (opcode == op_J) {
                // alterando os bits de "next state" para o estado 9
                ns0 = 1;
                ns1 = 0;
                ns2 = 0;
                ns3 = 1;

            } else if (opcode == op_ANDI){
                // alterando os bits de "next state" para o estado 15
                ns0 = 1;
                ns1 = 1;
                ns2 = 1;
                ns3 = 1;

            } else if (opcode == op_JALR){
                // alterando os bits de "next state" para o estado 14
                ns0 = 0;
                ns1 = 1;
                ns2 = 1;
                ns3 = 1;

            } else if (opcode == op_BNE){
                // alterando os bits de "next state" para o estado 12
                ns0 = 0;
                ns1 = 0;
                ns2 = 1;
                ns3 = 1;

            } else if (opcode == op_JR){
                // alterando os bits de "next state" para o estado 10
                ns0 = 0;
                ns1 = 1;
                ns2 = 0;
                ns3 = 1;
                
            } else if (opcode == op_JAL){
                // alterando os bits de "next state" para o estado 13
                ns0 = 1;
                ns1 = 0;
                ns2 = 1;
                ns3 = 1;
            }
        }
    
    // a MEF está no estado 2
    else
        if (!s3 & !s2 & s1 & !s0) {
            if (opcode == op_LW) {
                // alterando os bits de "next state" para o estado 3
                ns0 = 1;
                ns1 = 1;
                ns2 = 0;
                ns3 = 0;

            } else if (opcode == op_SW) {
                // alterando os bits de "next state" para o estado 5
                ns0 = 1;
                ns1 = 0;
                ns2 = 1;
                ns3 = 0;

            } else if (opcode == op_ADDI){
                // alterando os bits "next state" para o estado 11
                ns0 = 1;
                ns1 = 1;
                ns2 = 0;
                ns3 = 1;
            }
        }
    // a MEF está no estado 3
    else
        if (!s3 & !s2 &  s1 &  s0) {
        // alterando os bits de "next state" para o estado 4
        ns0 = 0;
        ns1 = 0;
        ns2 = 1;
        ns3 = 0;

    }
    // a MEF está no estado 4
    else
        if (!s3 & s2 & !s1 & !s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }
    // a MEF está no estado 5
    else
        if (!s3 &  s2 & !s1 & s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }
    // a MEF está no estado 6
    else
        if (!s3 &  s2 &  s1 & !s0) {
        // alterando os bits de "next state" para o estado 7
        ns0 = 1;
        ns1 = 1;
        ns2 = 1;
        ns3 = 0;

    }
    // a MEF está no estado 7
    else
        if (!s3 &  s2 &  s1 &  s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }
    // a MEF está no estado 8
    else
        if (s3 & !s2 & !s1 & !s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }
    // a MEF está no estado 9
    else
        if (s3 & !s2 & !s1 &  s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }

    // a MEF está no estado 10
    else
        if (s3 & !s2 &  s1 & !s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }

    // a MEF está no estado 11
    else
        if (s3 & !s2 &  s1 &  s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }

    // a MEF está no estado 12
    else
        if (s3 &  s2 & !s1 & !s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }

        // a MEF está no estado 13
    else
        if (s3 &  s2 & !s1 &  s0) {
        // alterando os bits de "next state" para o estado 0
        ns0 = 0;
        ns1 = 0;
        ns2 = 0;
        ns3 = 0;

    }

    // a MEF está no estado 14
    else
        if (s3 &  s2 &  s1 & !s0) {
        // alterando os bits de "next state" para o estado 10
        ns0 = 0;
        ns1 = 1;
        ns2 = 0;
        ns3 = 1;

    }

    // a MEF está no estado 15
    else
        if (s3 &  s2 &  s1 &  s0) {
        // alterando os bits de "next state" para o estado 11
        ns0 = 1;
        ns1 = 1;
        ns2 = 0;
        ns3 = 1;

    }


    printf("\nEstado atual: %d \n", estado);
    // atualizando o estado
    ProxEstado(ns0, ns1, ns2, ns3);
    
    printf("Prox estado: %d \n", estado);

    // atualizando os sinais de controle
    return GeraSinais(s0, s1, s2, s3);

}